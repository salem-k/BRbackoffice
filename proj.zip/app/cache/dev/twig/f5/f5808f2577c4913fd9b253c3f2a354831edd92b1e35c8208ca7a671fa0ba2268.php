<?php

/* TwigBundle:Exception:exception.css.twig */
class __TwigTemplate_ecd12ce1f4802715c0d4dbb82320e587cda0a2b8f38a434977aab9b94ca899ac extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_af7e92c674826c7498a2d2aea734dc19161770448f8a1f93528c7c5dc21980e8 = $this->env->getExtension("native_profiler");
        $__internal_af7e92c674826c7498a2d2aea734dc19161770448f8a1f93528c7c5dc21980e8->enter($__internal_af7e92c674826c7498a2d2aea734dc19161770448f8a1f93528c7c5dc21980e8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        $this->loadTemplate("TwigBundle:Exception:exception.txt.twig", "TwigBundle:Exception:exception.css.twig", 2)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        // line 3
        echo "*/
";
        
        $__internal_af7e92c674826c7498a2d2aea734dc19161770448f8a1f93528c7c5dc21980e8->leave($__internal_af7e92c674826c7498a2d2aea734dc19161770448f8a1f93528c7c5dc21980e8_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  27 => 3,  25 => 2,  22 => 1,);
    }
}
/* /**/
/* {% include 'TwigBundle:Exception:exception.txt.twig' with { 'exception': exception } %}*/
/* *//* */
/* */
