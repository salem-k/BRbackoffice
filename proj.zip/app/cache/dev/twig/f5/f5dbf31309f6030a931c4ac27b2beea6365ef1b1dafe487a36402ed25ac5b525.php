<?php

/* ::base.html.twig */
class __TwigTemplate_26dc48b74f5e689091f575a220808ba0eb2d7106fc58cec6b43e3e43ccb528e5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fcd910bb7fd197b675bd4bf3961272a09521729e92ed7cf2dd14b9a755d67fb3 = $this->env->getExtension("native_profiler");
        $__internal_fcd910bb7fd197b675bd4bf3961272a09521729e92ed7cf2dd14b9a755d67fb3->enter($__internal_fcd910bb7fd197b675bd4bf3961272a09521729e92ed7cf2dd14b9a755d67fb3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        ";
        // line 10
        $this->displayBlock('body', $context, $blocks);
        // line 11
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 12
        echo "    </body>
</html>
";
        
        $__internal_fcd910bb7fd197b675bd4bf3961272a09521729e92ed7cf2dd14b9a755d67fb3->leave($__internal_fcd910bb7fd197b675bd4bf3961272a09521729e92ed7cf2dd14b9a755d67fb3_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_96995af82ac3bf81779ea1e749c5d869d434ef8ee09d9d1b91bfe5cf53fbfc66 = $this->env->getExtension("native_profiler");
        $__internal_96995af82ac3bf81779ea1e749c5d869d434ef8ee09d9d1b91bfe5cf53fbfc66->enter($__internal_96995af82ac3bf81779ea1e749c5d869d434ef8ee09d9d1b91bfe5cf53fbfc66_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_96995af82ac3bf81779ea1e749c5d869d434ef8ee09d9d1b91bfe5cf53fbfc66->leave($__internal_96995af82ac3bf81779ea1e749c5d869d434ef8ee09d9d1b91bfe5cf53fbfc66_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_6c236767584a11bf6af6a7914aa4486edb8c03fb4503b9b146c7240f81cbcd28 = $this->env->getExtension("native_profiler");
        $__internal_6c236767584a11bf6af6a7914aa4486edb8c03fb4503b9b146c7240f81cbcd28->enter($__internal_6c236767584a11bf6af6a7914aa4486edb8c03fb4503b9b146c7240f81cbcd28_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_6c236767584a11bf6af6a7914aa4486edb8c03fb4503b9b146c7240f81cbcd28->leave($__internal_6c236767584a11bf6af6a7914aa4486edb8c03fb4503b9b146c7240f81cbcd28_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_3c54471f3d5bef52ae74783a2054719c864485a8da087a2bfca8d2ae8ad59a5e = $this->env->getExtension("native_profiler");
        $__internal_3c54471f3d5bef52ae74783a2054719c864485a8da087a2bfca8d2ae8ad59a5e->enter($__internal_3c54471f3d5bef52ae74783a2054719c864485a8da087a2bfca8d2ae8ad59a5e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_3c54471f3d5bef52ae74783a2054719c864485a8da087a2bfca8d2ae8ad59a5e->leave($__internal_3c54471f3d5bef52ae74783a2054719c864485a8da087a2bfca8d2ae8ad59a5e_prof);

    }

    // line 11
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_3962774bc8b02f314b6184451250d05cec076378e07f2f0bd4ac8ca3ce148f2f = $this->env->getExtension("native_profiler");
        $__internal_3962774bc8b02f314b6184451250d05cec076378e07f2f0bd4ac8ca3ce148f2f->enter($__internal_3962774bc8b02f314b6184451250d05cec076378e07f2f0bd4ac8ca3ce148f2f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_3962774bc8b02f314b6184451250d05cec076378e07f2f0bd4ac8ca3ce148f2f->leave($__internal_3962774bc8b02f314b6184451250d05cec076378e07f2f0bd4ac8ca3ce148f2f_prof);

    }

    public function getTemplateName()
    {
        return "::base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  93 => 11,  82 => 10,  71 => 6,  59 => 5,  50 => 12,  47 => 11,  45 => 10,  38 => 7,  36 => 6,  32 => 5,  26 => 1,);
    }
}
/* <!DOCTYPE html>*/
/* <html>*/
/*     <head>*/
/*         <meta charset="UTF-8" />*/
/*         <title>{% block title %}Welcome!{% endblock %}</title>*/
/*         {% block stylesheets %}{% endblock %}*/
/*         <link rel="icon" type="image/x-icon" href="{{ asset('favicon.ico') }}" />*/
/*     </head>*/
/*     <body>*/
/*         {% block body %}{% endblock %}*/
/*         {% block javascripts %}{% endblock %}*/
/*     </body>*/
/* </html>*/
/* */
