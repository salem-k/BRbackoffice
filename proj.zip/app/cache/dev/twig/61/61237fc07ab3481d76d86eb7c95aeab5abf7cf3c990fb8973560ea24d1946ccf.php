<?php

/* TwigBundle:Exception:exception.rdf.twig */
class __TwigTemplate_95a370a731263c2cc6d5f762ab89dcba1ce9eb5e0e9e3edc78447d6693fd2c5b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_726e3f7fed9758b9bed14e5a60f770707b1479281f45879810d78c81cafdffab = $this->env->getExtension("native_profiler");
        $__internal_726e3f7fed9758b9bed14e5a60f770707b1479281f45879810d78c81cafdffab->enter($__internal_726e3f7fed9758b9bed14e5a60f770707b1479281f45879810d78c81cafdffab_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.rdf.twig"));

        // line 1
        $this->loadTemplate("TwigBundle:Exception:exception.xml.twig", "TwigBundle:Exception:exception.rdf.twig", 1)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        
        $__internal_726e3f7fed9758b9bed14e5a60f770707b1479281f45879810d78c81cafdffab->leave($__internal_726e3f7fed9758b9bed14e5a60f770707b1479281f45879810d78c81cafdffab_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include 'TwigBundle:Exception:exception.xml.twig' with { 'exception': exception } %}*/
/* */
