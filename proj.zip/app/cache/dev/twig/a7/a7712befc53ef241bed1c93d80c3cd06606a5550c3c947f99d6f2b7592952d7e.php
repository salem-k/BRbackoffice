<?php

/* AppBundle:Sequence:show.html.twig */
class __TwigTemplate_5935bce0de1cebd06ef873c1226ed49ff3fb44593dcc0aeb592343cc379fa97d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("AppBundle::layout.html.twig", "AppBundle:Sequence:show.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "AppBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_12555ef5a864e735cc50c2c20dc7c89d5fbda9869d530d5d7b828847729f5a57 = $this->env->getExtension("native_profiler");
        $__internal_12555ef5a864e735cc50c2c20dc7c89d5fbda9869d530d5d7b828847729f5a57->enter($__internal_12555ef5a864e735cc50c2c20dc7c89d5fbda9869d530d5d7b828847729f5a57_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Sequence:show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_12555ef5a864e735cc50c2c20dc7c89d5fbda9869d530d5d7b828847729f5a57->leave($__internal_12555ef5a864e735cc50c2c20dc7c89d5fbda9869d530d5d7b828847729f5a57_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_c9ae22a2219202d6d4d736581e115e408198e23cdabfcf7888b4351fea6129cc = $this->env->getExtension("native_profiler");
        $__internal_c9ae22a2219202d6d4d736581e115e408198e23cdabfcf7888b4351fea6129cc->enter($__internal_c9ae22a2219202d6d4d736581e115e408198e23cdabfcf7888b4351fea6129cc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "<h1>Sequence</h1>

    <table class=\"record_properties\">
        <tbody>
            <tr>
                <th>Id</th>
                <td>";
        // line 10
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["entity"]) ? $context["entity"] : $this->getContext($context, "entity")), "id", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Name</th>
                <td>";
        // line 14
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["entity"]) ? $context["entity"] : $this->getContext($context, "entity")), "name", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Description</th>
                <td>";
        // line 18
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["entity"]) ? $context["entity"] : $this->getContext($context, "entity")), "description", array()), "html", null, true);
        echo "</td>
            </tr>
        </tbody>
    </table>

        <ul class=\"record_actions\">
    <li>
        <a href=\"";
        // line 25
        echo $this->env->getExtension('routing')->getPath("sequence");
        echo "\">
            Back to the list
        </a>
    </li>
    <li>
        <a href=\"";
        // line 30
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("sequence_edit", array("id" => $this->getAttribute((isset($context["entity"]) ? $context["entity"] : $this->getContext($context, "entity")), "id", array()))), "html", null, true);
        echo "\">
            Edit
        </a>
    </li>
    <li>";
        // line 34
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form');
        echo "</li>
</ul>
";
        
        $__internal_c9ae22a2219202d6d4d736581e115e408198e23cdabfcf7888b4351fea6129cc->leave($__internal_c9ae22a2219202d6d4d736581e115e408198e23cdabfcf7888b4351fea6129cc_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Sequence:show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  87 => 34,  80 => 30,  72 => 25,  62 => 18,  55 => 14,  48 => 10,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'AppBundle::layout.html.twig' %}*/
/* */
/* {% block body -%}*/
/*     <h1>Sequence</h1>*/
/* */
/*     <table class="record_properties">*/
/*         <tbody>*/
/*             <tr>*/
/*                 <th>Id</th>*/
/*                 <td>{{ entity.id }}</td>*/
/*             </tr>*/
/*             <tr>*/
/*                 <th>Name</th>*/
/*                 <td>{{ entity.name }}</td>*/
/*             </tr>*/
/*             <tr>*/
/*                 <th>Description</th>*/
/*                 <td>{{ entity.description }}</td>*/
/*             </tr>*/
/*         </tbody>*/
/*     </table>*/
/* */
/*         <ul class="record_actions">*/
/*     <li>*/
/*         <a href="{{ path('sequence') }}">*/
/*             Back to the list*/
/*         </a>*/
/*     </li>*/
/*     <li>*/
/*         <a href="{{ path('sequence_edit', { 'id': entity.id }) }}">*/
/*             Edit*/
/*         </a>*/
/*     </li>*/
/*     <li>{{ form(delete_form) }}</li>*/
/* </ul>*/
/* {% endblock %}*/
/* */
