<?php

/* SensioDistributionBundle:Configurator:form.html.twig */
class __TwigTemplate_f77865616ffab207f6d35f7575abdbc2ecd946dc6134292288e6a6c486453bc8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("form_div_layout.html.twig", "SensioDistributionBundle:Configurator:form.html.twig", 1);
        $this->blocks = array(
            'form_rows' => array($this, 'block_form_rows'),
            'form_row' => array($this, 'block_form_row'),
            'form_label' => array($this, 'block_form_label'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "form_div_layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1ee02f9c91368587b1aa5ae8f486e65fe20c7259039343210479d1c457964b19 = $this->env->getExtension("native_profiler");
        $__internal_1ee02f9c91368587b1aa5ae8f486e65fe20c7259039343210479d1c457964b19->enter($__internal_1ee02f9c91368587b1aa5ae8f486e65fe20c7259039343210479d1c457964b19_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SensioDistributionBundle:Configurator:form.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_1ee02f9c91368587b1aa5ae8f486e65fe20c7259039343210479d1c457964b19->leave($__internal_1ee02f9c91368587b1aa5ae8f486e65fe20c7259039343210479d1c457964b19_prof);

    }

    // line 3
    public function block_form_rows($context, array $blocks = array())
    {
        $__internal_17e3fa1e27958ad72bb334301f179da65e388fa54e4130b53cef434f84e31947 = $this->env->getExtension("native_profiler");
        $__internal_17e3fa1e27958ad72bb334301f179da65e388fa54e4130b53cef434f84e31947->enter($__internal_17e3fa1e27958ad72bb334301f179da65e388fa54e4130b53cef434f84e31947_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_rows"));

        // line 4
        echo "    <div class=\"symfony-form-errors\">
        ";
        // line 5
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'errors');
        echo "
    </div>
    ";
        // line 7
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")));
        foreach ($context['_seq'] as $context["_key"] => $context["child"]) {
            // line 8
            echo "        ";
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($context["child"], 'row');
            echo "
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['child'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        
        $__internal_17e3fa1e27958ad72bb334301f179da65e388fa54e4130b53cef434f84e31947->leave($__internal_17e3fa1e27958ad72bb334301f179da65e388fa54e4130b53cef434f84e31947_prof);

    }

    // line 12
    public function block_form_row($context, array $blocks = array())
    {
        $__internal_69bf6188a387d53912fa4c004292c9d7f01c669e2304544b735c0fdc2256e744 = $this->env->getExtension("native_profiler");
        $__internal_69bf6188a387d53912fa4c004292c9d7f01c669e2304544b735c0fdc2256e744->enter($__internal_69bf6188a387d53912fa4c004292c9d7f01c669e2304544b735c0fdc2256e744_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_row"));

        // line 13
        echo "    <div class=\"symfony-form-row\">
        ";
        // line 14
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'label');
        echo "
        <div class=\"symfony-form-field\">
            ";
        // line 16
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
            <div class=\"symfony-form-errors\">
                ";
        // line 18
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'errors');
        echo "
            </div>
        </div>
    </div>
";
        
        $__internal_69bf6188a387d53912fa4c004292c9d7f01c669e2304544b735c0fdc2256e744->leave($__internal_69bf6188a387d53912fa4c004292c9d7f01c669e2304544b735c0fdc2256e744_prof);

    }

    // line 24
    public function block_form_label($context, array $blocks = array())
    {
        $__internal_1701a94b08ffcc1c3f7d084ae39972a0c117233c549ab093b5ebf1bb9cfa4377 = $this->env->getExtension("native_profiler");
        $__internal_1701a94b08ffcc1c3f7d084ae39972a0c117233c549ab093b5ebf1bb9cfa4377->enter($__internal_1701a94b08ffcc1c3f7d084ae39972a0c117233c549ab093b5ebf1bb9cfa4377_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_label"));

        // line 25
        echo "    ";
        if (twig_test_empty((isset($context["label"]) ? $context["label"] : $this->getContext($context, "label")))) {
            // line 26
            echo "        ";
            $context["label"] = $this->env->getExtension('form')->humanize((isset($context["name"]) ? $context["name"] : $this->getContext($context, "name")));
            // line 27
            echo "    ";
        }
        // line 28
        echo "    <label for=\"";
        echo twig_escape_filter($this->env, (isset($context["id"]) ? $context["id"] : $this->getContext($context, "id")), "html", null, true);
        echo "\">
        ";
        // line 29
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans((isset($context["label"]) ? $context["label"] : $this->getContext($context, "label"))), "html", null, true);
        echo "
        ";
        // line 30
        if ((isset($context["required"]) ? $context["required"] : $this->getContext($context, "required"))) {
            // line 31
            echo "            <span class=\"symfony-form-required\" title=\"This field is required\">*</span>
        ";
        }
        // line 33
        echo "    </label>
";
        
        $__internal_1701a94b08ffcc1c3f7d084ae39972a0c117233c549ab093b5ebf1bb9cfa4377->leave($__internal_1701a94b08ffcc1c3f7d084ae39972a0c117233c549ab093b5ebf1bb9cfa4377_prof);

    }

    public function getTemplateName()
    {
        return "SensioDistributionBundle:Configurator:form.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  129 => 33,  125 => 31,  123 => 30,  119 => 29,  114 => 28,  111 => 27,  108 => 26,  105 => 25,  99 => 24,  87 => 18,  82 => 16,  77 => 14,  74 => 13,  68 => 12,  54 => 8,  50 => 7,  45 => 5,  42 => 4,  36 => 3,  11 => 1,);
    }
}
/* {% extends "form_div_layout.html.twig" %}*/
/* */
/* {% block form_rows %}*/
/*     <div class="symfony-form-errors">*/
/*         {{ form_errors(form) }}*/
/*     </div>*/
/*     {% for child in form %}*/
/*         {{ form_row(child) }}*/
/*     {% endfor %}*/
/* {% endblock %}*/
/* */
/* {% block form_row %}*/
/*     <div class="symfony-form-row">*/
/*         {{ form_label(form) }}*/
/*         <div class="symfony-form-field">*/
/*             {{ form_widget(form) }}*/
/*             <div class="symfony-form-errors">*/
/*                 {{ form_errors(form) }}*/
/*             </div>*/
/*         </div>*/
/*     </div>*/
/* {% endblock %}*/
/* */
/* {% block form_label %}*/
/*     {% if label is empty %}*/
/*         {% set label = name|humanize %}*/
/*     {% endif %}*/
/*     <label for="{{ id }}">*/
/*         {{ label|trans }}*/
/*         {% if required %}*/
/*             <span class="symfony-form-required" title="This field is required">*</span>*/
/*         {% endif %}*/
/*     </label>*/
/* {% endblock %}*/
/* */
