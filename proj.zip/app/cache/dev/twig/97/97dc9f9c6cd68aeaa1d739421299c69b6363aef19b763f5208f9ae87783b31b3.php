<?php

/* AppBundle:Default:index.html.twig */
class __TwigTemplate_4fddcb94640cd50374326391f92c234b00e3839947d5daded45510827cb33761 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 2
        $this->parent = $this->loadTemplate("AppBundle::layout.html.twig", "AppBundle:Default:index.html.twig", 2);
        $this->blocks = array(
            'javascripts' => array($this, 'block_javascripts'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "AppBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_17dac748c8766943b8cf183d74a0309bb80a1e98b2d3b6be77c7b274e38524e0 = $this->env->getExtension("native_profiler");
        $__internal_17dac748c8766943b8cf183d74a0309bb80a1e98b2d3b6be77c7b274e38524e0->enter($__internal_17dac748c8766943b8cf183d74a0309bb80a1e98b2d3b6be77c7b274e38524e0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Default:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_17dac748c8766943b8cf183d74a0309bb80a1e98b2d3b6be77c7b274e38524e0->leave($__internal_17dac748c8766943b8cf183d74a0309bb80a1e98b2d3b6be77c7b274e38524e0_prof);

    }

    // line 3
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_1dbabc56edb04eeb9fa0e596635505754178ddc1ce80cd91f01e27577949b95c = $this->env->getExtension("native_profiler");
        $__internal_1dbabc56edb04eeb9fa0e596635505754178ddc1ce80cd91f01e27577949b95c->enter($__internal_1dbabc56edb04eeb9fa0e596635505754178ddc1ce80cd91f01e27577949b95c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 4
        echo "
<script type=\"text/javascript\">
  function executeEvent (){
    var label = \$(\"#appbundle_event_label\").val();
    var text = \$(\"#appbundle_event_text\").val();
    var textcolor = \$(\"#appbundle_event_textcolor\").val();
    var bgcolor = \$(\"#appbundle_event_bgcolor\").val();
    var image = \$(\"#appbundle_event_image\").val();
    var sound = \$(\"#appbundle_event_sound\").val();
    var time = \$(\"#appbundle_event_time\").val();
    execute( label, text, textcolor, bgcolor, image, sound , time);
  }
  function execute( label, text, textcolor, bgcolor, image, sound , time){
    \$.ajax({
      method: \"POST\",
      url: \"";
        // line 19
        echo $this->env->getExtension('routing')->getPath("event_execute");
        echo "\",
      data: { label: label, text: text, textcolor: textcolor, bgcolor: bgcolor, image: image, sound: sound , time : time },
    }).success(function(data,status,header){
      if (\"ok\" == data){
        \$(\"#success-alert\").fadeTo(2000, 500).slideUp(500, function(){
            \$(\"#success-alert\").alert('close');
          });
      }else{
        \$(\"#alert-danger\").fadeTo(2000, 500).slideUp(500, function(){
            \$(\"#alert-danger\").alert('close');
          });
      }

    }).error(function(error,jqx,header){
        console.log(error);
    });
  }
//--------  alert  --------
\$(document).ready (function(){
    \$(\"#success-alert\").hide();
    \$(\"#alert-danger\").hide();

 });

</script>
";
        
        $__internal_1dbabc56edb04eeb9fa0e596635505754178ddc1ce80cd91f01e27577949b95c->leave($__internal_1dbabc56edb04eeb9fa0e596635505754178ddc1ce80cd91f01e27577949b95c_prof);

    }

    // line 47
    public function block_body($context, array $blocks = array())
    {
        $__internal_f9e9f660c3a7f13ef2c469956ecf50e3761b858ec7bcced12cfc5b488dffc5e9 = $this->env->getExtension("native_profiler");
        $__internal_f9e9f660c3a7f13ef2c469956ecf50e3761b858ec7bcced12cfc5b488dffc5e9->enter($__internal_f9e9f660c3a7f13ef2c469956ecf50e3761b858ec7bcced12cfc5b488dffc5e9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 48
        echo "


<div class=\"well\">
  <h3>Evennement encours :</h3><br />

</div>

<div class=\"well\">
  <h3>Evenement manuel :</h3>
  ";
        // line 58
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["eventForm"]) ? $context["eventForm"] : $this->getContext($context, "eventForm")), 'form', array("style" => "inline"));
        echo "
  <nav>
  <ul class=\"pager\">
    <li class=\"next\">
    <a href=\"javascript:void(0)\" onclick=\"executeEvent()\" >lancer l'evenement >></a>
    </li>
  </ul>
</nav>



</div>

<div class=\"btn-group-vertical\" role=\"group\" aria-label=\"...\">
  <button type=\"button\" class=\"btn btn-warning\" style=\"text-align: left;\" onclick=\"execute( 'Ecran Jaune', '', '', '#D2D490', '', '' , '10000');\">Bouton “Go” : Ecran Jaune</button>
  <button type=\"button\" class=\"btn btn-success\" style=\"text-align: left;\" onclick=\"execute( 'Ecran Vert', '', '', '#287820', '', '' , '10000');\">Bouton “Go” : Ecran Vert</button>
  <button type=\"button\" class=\"btn btn-danger\" style=\"text-align: left;\" onclick=\"execute( 'Ecran Rouge', '', '', '#B52410', '', '' , '10000');\">Bouton “Go” : Ecran Rouge</button>
  <button type=\"button\" class=\"btn label-default\" style=\"text-align: left;\" onclick=\"execute( 'Ecran Noir', '', '', '#000000', '', '' , '10000');\">Bouton “Go” : Ecran Noir avec écrit en blanc “Batelier Records”.</button>
  <button type=\"button\" class=\"btn label-default\" style=\"text-align: left;\" onclick=\"execute( 'Ecran Blanc', '', '', '#ffffff', '', '' , '10000');\">Bouton “Go” : Bouton “Go” : Ecran blanc avec le logo de Batelier Records</button>
</div>


<table class=\"table table-hover\">
  <thead>
    <tr>
      <th>Firstname</th>
      <th>Lastname</th>
      <th>Email</th>
    </tr>
  </thead>
  <tbody>
    ";
        // line 89
        echo $this->env->getExtension('dump')->dump($this->env, $context, (isset($context["entities"]) ? $context["entities"] : $this->getContext($context, "entities")));
        echo "
";
        // line 90
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["entities"]) ? $context["entities"] : $this->getContext($context, "entities")));
        foreach ($context['_seq'] as $context["_key"] => $context["temp"]) {
            // line 91
            echo "<tr>
  <td>";
            // line 92
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "name", array()), "html", null, true);
            echo "</td>
  <td>";
            // line 93
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "description", array()), "html", null, true);
            echo "</td>
  <td><button type=\"submit\" class=\"btn btn-default\" style=\"float:right;\">Lancer cette sequence</button></td>
</tr>
<tr>
  <td></td>
  <td colspan=\"2\">
    <table class=\"table table-hover\">
        ";
            // line 100
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($context["temp"], "events", array()));
            foreach ($context['_seq'] as $context["_key"] => $context["temp1"]) {
                // line 101
                echo "        <tr>
          <td>";
                // line 102
                echo twig_escape_filter($this->env, $this->getAttribute($context["temp1"], "label", array()), "html", null, true);
                echo "</td>
          <td>";
                // line 103
                echo twig_escape_filter($this->env, $this->getAttribute($context["temp1"], "text", array()), "html", null, true);
                echo "</td>
          <td>";
                // line 104
                echo twig_escape_filter($this->env, $this->getAttribute($context["temp1"], "textcolor", array()), "html", null, true);
                echo "</td>
        </tr>
        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['temp1'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 107
            echo "    </table>
  </td>
</tr>
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['temp'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 111
        echo "  </tbody>
</table>
";
        
        $__internal_f9e9f660c3a7f13ef2c469956ecf50e3761b858ec7bcced12cfc5b488dffc5e9->leave($__internal_f9e9f660c3a7f13ef2c469956ecf50e3761b858ec7bcced12cfc5b488dffc5e9_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Default:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  201 => 111,  192 => 107,  183 => 104,  179 => 103,  175 => 102,  172 => 101,  168 => 100,  158 => 93,  154 => 92,  151 => 91,  147 => 90,  143 => 89,  109 => 58,  97 => 48,  91 => 47,  58 => 19,  41 => 4,  35 => 3,  11 => 2,);
    }
}
/* */
/* {% extends 'AppBundle::layout.html.twig' %}*/
/* {% block javascripts %}*/
/* */
/* <script type="text/javascript">*/
/*   function executeEvent (){*/
/*     var label = $("#appbundle_event_label").val();*/
/*     var text = $("#appbundle_event_text").val();*/
/*     var textcolor = $("#appbundle_event_textcolor").val();*/
/*     var bgcolor = $("#appbundle_event_bgcolor").val();*/
/*     var image = $("#appbundle_event_image").val();*/
/*     var sound = $("#appbundle_event_sound").val();*/
/*     var time = $("#appbundle_event_time").val();*/
/*     execute( label, text, textcolor, bgcolor, image, sound , time);*/
/*   }*/
/*   function execute( label, text, textcolor, bgcolor, image, sound , time){*/
/*     $.ajax({*/
/*       method: "POST",*/
/*       url: "{{ path('event_execute') }}",*/
/*       data: { label: label, text: text, textcolor: textcolor, bgcolor: bgcolor, image: image, sound: sound , time : time },*/
/*     }).success(function(data,status,header){*/
/*       if ("ok" == data){*/
/*         $("#success-alert").fadeTo(2000, 500).slideUp(500, function(){*/
/*             $("#success-alert").alert('close');*/
/*           });*/
/*       }else{*/
/*         $("#alert-danger").fadeTo(2000, 500).slideUp(500, function(){*/
/*             $("#alert-danger").alert('close');*/
/*           });*/
/*       }*/
/* */
/*     }).error(function(error,jqx,header){*/
/*         console.log(error);*/
/*     });*/
/*   }*/
/* //--------  alert  --------*/
/* $(document).ready (function(){*/
/*     $("#success-alert").hide();*/
/*     $("#alert-danger").hide();*/
/* */
/*  });*/
/* */
/* </script>*/
/* {% endblock %}*/
/* */
/* */
/* {% block body %}*/
/* */
/* */
/* */
/* <div class="well">*/
/*   <h3>Evennement encours :</h3><br />*/
/* */
/* </div>*/
/* */
/* <div class="well">*/
/*   <h3>Evenement manuel :</h3>*/
/*   {{ form( eventForm, { 'style': 'inline' } ) }}*/
/*   <nav>*/
/*   <ul class="pager">*/
/*     <li class="next">*/
/*     <a href="javascript:void(0)" onclick="executeEvent()" >lancer l'evenement >></a>*/
/*     </li>*/
/*   </ul>*/
/* </nav>*/
/* */
/* */
/* */
/* </div>*/
/* */
/* <div class="btn-group-vertical" role="group" aria-label="...">*/
/*   <button type="button" class="btn btn-warning" style="text-align: left;" onclick="execute( 'Ecran Jaune', '', '', '#D2D490', '', '' , '10000');">Bouton “Go” : Ecran Jaune</button>*/
/*   <button type="button" class="btn btn-success" style="text-align: left;" onclick="execute( 'Ecran Vert', '', '', '#287820', '', '' , '10000');">Bouton “Go” : Ecran Vert</button>*/
/*   <button type="button" class="btn btn-danger" style="text-align: left;" onclick="execute( 'Ecran Rouge', '', '', '#B52410', '', '' , '10000');">Bouton “Go” : Ecran Rouge</button>*/
/*   <button type="button" class="btn label-default" style="text-align: left;" onclick="execute( 'Ecran Noir', '', '', '#000000', '', '' , '10000');">Bouton “Go” : Ecran Noir avec écrit en blanc “Batelier Records”.</button>*/
/*   <button type="button" class="btn label-default" style="text-align: left;" onclick="execute( 'Ecran Blanc', '', '', '#ffffff', '', '' , '10000');">Bouton “Go” : Bouton “Go” : Ecran blanc avec le logo de Batelier Records</button>*/
/* </div>*/
/* */
/* */
/* <table class="table table-hover">*/
/*   <thead>*/
/*     <tr>*/
/*       <th>Firstname</th>*/
/*       <th>Lastname</th>*/
/*       <th>Email</th>*/
/*     </tr>*/
/*   </thead>*/
/*   <tbody>*/
/*     {{dump(entities)}}*/
/* {% for temp in entities %}*/
/* <tr>*/
/*   <td>{{temp.name}}</td>*/
/*   <td>{{temp.description}}</td>*/
/*   <td><button type="submit" class="btn btn-default" style="float:right;">Lancer cette sequence</button></td>*/
/* </tr>*/
/* <tr>*/
/*   <td></td>*/
/*   <td colspan="2">*/
/*     <table class="table table-hover">*/
/*         {% for temp1 in temp.events %}*/
/*         <tr>*/
/*           <td>{{temp1.label}}</td>*/
/*           <td>{{temp1.text}}</td>*/
/*           <td>{{temp1.textcolor}}</td>*/
/*         </tr>*/
/*         {% endfor %}*/
/*     </table>*/
/*   </td>*/
/* </tr>*/
/* {% endfor %}*/
/*   </tbody>*/
/* </table>*/
/* {% endblock %}*/
/* */
