<?php

/* AppBundle:Default:index.html.twig */
class __TwigTemplate_4fddcb94640cd50374326391f92c234b00e3839947d5daded45510827cb33761 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 2
        $this->parent = $this->loadTemplate("AppBundle::layout.html.twig", "AppBundle:Default:index.html.twig", 2);
        $this->blocks = array(
            'javascripts' => array($this, 'block_javascripts'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "AppBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_850d635913abe0b40e663e5d3ac78268fd88e4442add01193764c28f7433d555 = $this->env->getExtension("native_profiler");
        $__internal_850d635913abe0b40e663e5d3ac78268fd88e4442add01193764c28f7433d555->enter($__internal_850d635913abe0b40e663e5d3ac78268fd88e4442add01193764c28f7433d555_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Default:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_850d635913abe0b40e663e5d3ac78268fd88e4442add01193764c28f7433d555->leave($__internal_850d635913abe0b40e663e5d3ac78268fd88e4442add01193764c28f7433d555_prof);

    }

    // line 3
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_4d7dce637e47f298712f0d33089b34971a56dd4d1f08cf9f1aff751e6f628899 = $this->env->getExtension("native_profiler");
        $__internal_4d7dce637e47f298712f0d33089b34971a56dd4d1f08cf9f1aff751e6f628899->enter($__internal_4d7dce637e47f298712f0d33089b34971a56dd4d1f08cf9f1aff751e6f628899_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 4
        echo "
<script type=\"text/javascript\">
  function executeEvent (){
    var label = \$(\"#appbundle_event_label\").val();
    var text = \$(\"#appbundle_event_text\").val();
    var textcolor = \$(\"#appbundle_event_textcolor\").val();
    var bgcolor = \$(\"#appbundle_event_bgcolor\").val();
    var image = \$(\"#appbundle_event_image\").val();
    var sound = \$(\"#appbundle_event_sound\").val();
    var time = \$(\"#appbundle_event_time\").val();

    \$.ajax({
      method: \"POST\",
      url: \"";
        // line 17
        echo $this->env->getExtension('routing')->getPath("event_execute");
        echo "\",
      data: { label: label, text: text, textcolor: textcolor, bgcolor: bgcolor, image: image, sound: sound , time : time },
    }).success(function(data,status,header){
      if (\"ok\" == data){
        \$(\"#success-alert\").fadeTo(2000, 500).slideUp(500, function(){
            \$(\"#success-alert\").alert('close');
          });
      }else{
        \$(\"#alert-danger\").fadeTo(2000, 500).slideUp(500, function(){
            \$(\"#alert-danger\").alert('close');
          });
      }

    }).error(function(error,jqx,header){
        console.log(error);
    });

  }
//--------  alert  --------
\$(document).ready (function(){
    \$(\"#success-alert\").hide();
    \$(\"#alert-danger\").hide();

    \$.ajax({
      method: \"POST\",
      url: \"";
        // line 42
        echo $this->env->getExtension('routing')->getPath("event_execute");
        echo "\",
      data: { label: label, text: text, textcolor: textcolor, bgcolor: bgcolor, image: image, sound: sound , time : time },
    }).success(function(data,status,header){
      if (\"ok\" == data){
        \$(\"#success-alert\").fadeTo(2000, 500).slideUp(500, function(){
            \$(\"#success-alert\").alert('close');
          });
      }else{
        \$(\"#alert-danger\").fadeTo(2000, 500).slideUp(500, function(){
            \$(\"#alert-danger\").alert('close');
          });
      }

    }).error(function(error,jqx,header){
        console.log(error);
    });
 });

</script>
";
        
        $__internal_4d7dce637e47f298712f0d33089b34971a56dd4d1f08cf9f1aff751e6f628899->leave($__internal_4d7dce637e47f298712f0d33089b34971a56dd4d1f08cf9f1aff751e6f628899_prof);

    }

    // line 64
    public function block_body($context, array $blocks = array())
    {
        $__internal_64bd59673fe335600da1706bb0d71f57877f47526ac7b2425545b822d9737d2f = $this->env->getExtension("native_profiler");
        $__internal_64bd59673fe335600da1706bb0d71f57877f47526ac7b2425545b822d9737d2f->enter($__internal_64bd59673fe335600da1706bb0d71f57877f47526ac7b2425545b822d9737d2f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 65
        echo "


<div class=\"well\">
  <h3>Evennement encours :</h3><br />

</div>

<div class=\"well\">
  <h3>Evenement manuel :</h3>
  ";
        // line 75
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["eventForm"]) ? $context["eventForm"] : $this->getContext($context, "eventForm")), 'form', array("style" => "inline"));
        echo "
  <nav>
  <ul class=\"pager\">
    <li class=\"next\">
    <a href=\"javascript:void(0)\" id=\"";
        // line 79
        echo $this->env->getExtension('routing')->getPath("event_execute");
        echo "\" class=\"executeOperation\" >lancer l'evenement >></a>
    </li>
  </ul>
</nav>



</div>

<div class=\"btn-group-vertical\" role=\"group\" aria-label=\"...\">
  <button type=\"button\" class=\"btn btn-warning\" style=\"text-align: left;\">Bouton “Go” : Ecran Jaune</button>
  <button type=\"button\" class=\"btn btn-success\" style=\"text-align: left;\">Bouton “Go” : Ecran Vert</button>
  <button type=\"button\" class=\"btn btn-danger\" style=\"text-align: left;\">Bouton “Go” : Ecran Rouge</button>
  <button type=\"button\" class=\"btn label-default\" style=\"text-align: left;\">Bouton “Go” : Ecran Noir avec écrit en blanc “Batelier Records”.</button>
  <button type=\"button\" class=\"btn label-default\" style=\"text-align: left;\">Bouton “Go” : Bouton “Go” : Ecran blanc avec le logo de Batelier Records</button>
</div>


<table class=\"table table-hover\">
  <thead>
    <tr>
      <th>Firstname</th>
      <th>Lastname</th>
      <th>Email</th>
    </tr>
  </thead>
  <tbody>
    ";
        // line 106
        echo $this->env->getExtension('dump')->dump($this->env, $context, (isset($context["entities"]) ? $context["entities"] : $this->getContext($context, "entities")));
        echo "
";
        // line 107
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["entities"]) ? $context["entities"] : $this->getContext($context, "entities")));
        foreach ($context['_seq'] as $context["_key"] => $context["temp"]) {
            // line 108
            echo "<tr>
  <td>";
            // line 109
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "name", array()), "html", null, true);
            echo "</td>
  <td>";
            // line 110
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "description", array()), "html", null, true);
            echo "</td>
  <td><button type=\"submit\" class=\"btn btn-default\" style=\"float:right;\">Lancer cette sequence</button></td>
</tr>
<tr>
  <td></td>
  <td colspan=\"2\">
    <table class=\"table table-hover\">
        ";
            // line 117
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($context["temp"], "events", array()));
            foreach ($context['_seq'] as $context["_key"] => $context["temp1"]) {
                // line 118
                echo "        <tr>
          <td>";
                // line 119
                echo twig_escape_filter($this->env, $this->getAttribute($context["temp1"], "label", array()), "html", null, true);
                echo "</td>
          <td>";
                // line 120
                echo twig_escape_filter($this->env, $this->getAttribute($context["temp1"], "text", array()), "html", null, true);
                echo "</td>
          <td>";
                // line 121
                echo twig_escape_filter($this->env, $this->getAttribute($context["temp1"], "textcolor", array()), "html", null, true);
                echo "</td>
        </tr>
        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['temp1'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 124
            echo "    </table>
  </td>
</tr>
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['temp'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 128
        echo "  </tbody>
</table>
";
        
        $__internal_64bd59673fe335600da1706bb0d71f57877f47526ac7b2425545b822d9737d2f->leave($__internal_64bd59673fe335600da1706bb0d71f57877f47526ac7b2425545b822d9737d2f_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Default:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  224 => 128,  215 => 124,  206 => 121,  202 => 120,  198 => 119,  195 => 118,  191 => 117,  181 => 110,  177 => 109,  174 => 108,  170 => 107,  166 => 106,  136 => 79,  129 => 75,  117 => 65,  111 => 64,  84 => 42,  56 => 17,  41 => 4,  35 => 3,  11 => 2,);
    }
}
/* */
/* {% extends 'AppBundle::layout.html.twig' %}*/
/* {% block javascripts %}*/
/* */
/* <script type="text/javascript">*/
/*   function executeEvent (){*/
/*     var label = $("#appbundle_event_label").val();*/
/*     var text = $("#appbundle_event_text").val();*/
/*     var textcolor = $("#appbundle_event_textcolor").val();*/
/*     var bgcolor = $("#appbundle_event_bgcolor").val();*/
/*     var image = $("#appbundle_event_image").val();*/
/*     var sound = $("#appbundle_event_sound").val();*/
/*     var time = $("#appbundle_event_time").val();*/
/* */
/*     $.ajax({*/
/*       method: "POST",*/
/*       url: "{{ path('event_execute') }}",*/
/*       data: { label: label, text: text, textcolor: textcolor, bgcolor: bgcolor, image: image, sound: sound , time : time },*/
/*     }).success(function(data,status,header){*/
/*       if ("ok" == data){*/
/*         $("#success-alert").fadeTo(2000, 500).slideUp(500, function(){*/
/*             $("#success-alert").alert('close');*/
/*           });*/
/*       }else{*/
/*         $("#alert-danger").fadeTo(2000, 500).slideUp(500, function(){*/
/*             $("#alert-danger").alert('close');*/
/*           });*/
/*       }*/
/* */
/*     }).error(function(error,jqx,header){*/
/*         console.log(error);*/
/*     });*/
/* */
/*   }*/
/* //--------  alert  --------*/
/* $(document).ready (function(){*/
/*     $("#success-alert").hide();*/
/*     $("#alert-danger").hide();*/
/* */
/*     $.ajax({*/
/*       method: "POST",*/
/*       url: "{{ path('event_execute') }}",*/
/*       data: { label: label, text: text, textcolor: textcolor, bgcolor: bgcolor, image: image, sound: sound , time : time },*/
/*     }).success(function(data,status,header){*/
/*       if ("ok" == data){*/
/*         $("#success-alert").fadeTo(2000, 500).slideUp(500, function(){*/
/*             $("#success-alert").alert('close');*/
/*           });*/
/*       }else{*/
/*         $("#alert-danger").fadeTo(2000, 500).slideUp(500, function(){*/
/*             $("#alert-danger").alert('close');*/
/*           });*/
/*       }*/
/* */
/*     }).error(function(error,jqx,header){*/
/*         console.log(error);*/
/*     });*/
/*  });*/
/* */
/* </script>*/
/* {% endblock %}*/
/* */
/* */
/* {% block body %}*/
/* */
/* */
/* */
/* <div class="well">*/
/*   <h3>Evennement encours :</h3><br />*/
/* */
/* </div>*/
/* */
/* <div class="well">*/
/*   <h3>Evenement manuel :</h3>*/
/*   {{ form( eventForm, { 'style': 'inline' } ) }}*/
/*   <nav>*/
/*   <ul class="pager">*/
/*     <li class="next">*/
/*     <a href="javascript:void(0)" id="{{ path('event_execute') }}" class="executeOperation" >lancer l'evenement >></a>*/
/*     </li>*/
/*   </ul>*/
/* </nav>*/
/* */
/* */
/* */
/* </div>*/
/* */
/* <div class="btn-group-vertical" role="group" aria-label="...">*/
/*   <button type="button" class="btn btn-warning" style="text-align: left;">Bouton “Go” : Ecran Jaune</button>*/
/*   <button type="button" class="btn btn-success" style="text-align: left;">Bouton “Go” : Ecran Vert</button>*/
/*   <button type="button" class="btn btn-danger" style="text-align: left;">Bouton “Go” : Ecran Rouge</button>*/
/*   <button type="button" class="btn label-default" style="text-align: left;">Bouton “Go” : Ecran Noir avec écrit en blanc “Batelier Records”.</button>*/
/*   <button type="button" class="btn label-default" style="text-align: left;">Bouton “Go” : Bouton “Go” : Ecran blanc avec le logo de Batelier Records</button>*/
/* </div>*/
/* */
/* */
/* <table class="table table-hover">*/
/*   <thead>*/
/*     <tr>*/
/*       <th>Firstname</th>*/
/*       <th>Lastname</th>*/
/*       <th>Email</th>*/
/*     </tr>*/
/*   </thead>*/
/*   <tbody>*/
/*     {{dump(entities)}}*/
/* {% for temp in entities %}*/
/* <tr>*/
/*   <td>{{temp.name}}</td>*/
/*   <td>{{temp.description}}</td>*/
/*   <td><button type="submit" class="btn btn-default" style="float:right;">Lancer cette sequence</button></td>*/
/* </tr>*/
/* <tr>*/
/*   <td></td>*/
/*   <td colspan="2">*/
/*     <table class="table table-hover">*/
/*         {% for temp1 in temp.events %}*/
/*         <tr>*/
/*           <td>{{temp1.label}}</td>*/
/*           <td>{{temp1.text}}</td>*/
/*           <td>{{temp1.textcolor}}</td>*/
/*         </tr>*/
/*         {% endfor %}*/
/*     </table>*/
/*   </td>*/
/* </tr>*/
/* {% endfor %}*/
/*   </tbody>*/
/* </table>*/
/* {% endblock %}*/
/* */
