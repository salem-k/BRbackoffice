<?php

/* TwigBundle:Exception:error.json.twig */
class __TwigTemplate_2475ba1a2436ab33c0921cb80f4eaa6c06c755aad632b17b96804b9c5dbfd0e2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7b9191dd5a68507021d49d586b60c74f9c4aa62fdd97472e0be64a06bcf351de = $this->env->getExtension("native_profiler");
        $__internal_7b9191dd5a68507021d49d586b60c74f9c4aa62fdd97472e0be64a06bcf351de->enter($__internal_7b9191dd5a68507021d49d586b60c74f9c4aa62fdd97472e0be64a06bcf351de_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.json.twig"));

        // line 1
        echo twig_jsonencode_filter(array("error" => array("code" => (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "message" => (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")))));
        echo "
";
        
        $__internal_7b9191dd5a68507021d49d586b60c74f9c4aa62fdd97472e0be64a06bcf351de->leave($__internal_7b9191dd5a68507021d49d586b60c74f9c4aa62fdd97472e0be64a06bcf351de_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {{ { 'error': { 'code': status_code, 'message': status_text } }|json_encode|raw }}*/
/* */
