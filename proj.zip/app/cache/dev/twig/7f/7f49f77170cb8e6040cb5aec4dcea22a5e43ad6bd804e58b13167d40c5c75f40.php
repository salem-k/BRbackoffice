<?php

/* TwigBundle:Exception:exception.atom.twig */
class __TwigTemplate_55f45f1d9f18ff2187cbeab911c62da9a2b0d72279648152bd2a4ad0e1d35cf5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ca2022200342cd8153dba0830bf820262225caf21239a02b9fe8f3340a0877a4 = $this->env->getExtension("native_profiler");
        $__internal_ca2022200342cd8153dba0830bf820262225caf21239a02b9fe8f3340a0877a4->enter($__internal_ca2022200342cd8153dba0830bf820262225caf21239a02b9fe8f3340a0877a4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.atom.twig"));

        // line 1
        $this->loadTemplate("TwigBundle:Exception:exception.xml.twig", "TwigBundle:Exception:exception.atom.twig", 1)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        
        $__internal_ca2022200342cd8153dba0830bf820262225caf21239a02b9fe8f3340a0877a4->leave($__internal_ca2022200342cd8153dba0830bf820262225caf21239a02b9fe8f3340a0877a4_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include 'TwigBundle:Exception:exception.xml.twig' with { 'exception': exception } %}*/
/* */
