<?php

/* TwigBundle:Exception:error.atom.twig */
class __TwigTemplate_300cff3447263f4fb0af4aacd77c98a61c69135de86d6873f885e08e12a4e533 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_817939bb6f33ef9a487bb140dfb21540d82da0d793bfe17463a604bf4c1f34f4 = $this->env->getExtension("native_profiler");
        $__internal_817939bb6f33ef9a487bb140dfb21540d82da0d793bfe17463a604bf4c1f34f4->enter($__internal_817939bb6f33ef9a487bb140dfb21540d82da0d793bfe17463a604bf4c1f34f4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.atom.twig"));

        // line 1
        $this->loadTemplate("TwigBundle:Exception:error.xml.twig", "TwigBundle:Exception:error.atom.twig", 1)->display($context);
        
        $__internal_817939bb6f33ef9a487bb140dfb21540d82da0d793bfe17463a604bf4c1f34f4->leave($__internal_817939bb6f33ef9a487bb140dfb21540d82da0d793bfe17463a604bf4c1f34f4_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.atom.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include 'TwigBundle:Exception:error.xml.twig' %}*/
/* */
