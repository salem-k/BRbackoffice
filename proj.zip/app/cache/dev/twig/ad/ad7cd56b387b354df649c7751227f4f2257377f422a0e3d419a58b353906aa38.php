<?php

/* BraincraftedBootstrapBundle::ie8-support.html.twig */
class __TwigTemplate_6455eb8321b070de5282c143f88c427447bbfd31b56f83b6fc491310981ccc4c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5702b64fe335d141a8c51f544bc1b0eaf0c4857c7f51eb16bb8fbb51ec437a5b = $this->env->getExtension("native_profiler");
        $__internal_5702b64fe335d141a8c51f544bc1b0eaf0c4857c7f51eb16bb8fbb51ec437a5b->enter($__internal_5702b64fe335d141a8c51f544bc1b0eaf0c4857c7f51eb16bb8fbb51ec437a5b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "BraincraftedBootstrapBundle::ie8-support.html.twig"));

        // line 1
        echo "<!--[if lt IE 9]>
    <script src=\"https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv-printshiv.min.js\"></script>
    <script src=\"https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js\"></script>
<![endif]-->
";
        
        $__internal_5702b64fe335d141a8c51f544bc1b0eaf0c4857c7f51eb16bb8fbb51ec437a5b->leave($__internal_5702b64fe335d141a8c51f544bc1b0eaf0c4857c7f51eb16bb8fbb51ec437a5b_prof);

    }

    public function getTemplateName()
    {
        return "BraincraftedBootstrapBundle::ie8-support.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <!--[if lt IE 9]>*/
/*     <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv-printshiv.min.js"></script>*/
/*     <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>*/
/* <![endif]-->*/
/* */
