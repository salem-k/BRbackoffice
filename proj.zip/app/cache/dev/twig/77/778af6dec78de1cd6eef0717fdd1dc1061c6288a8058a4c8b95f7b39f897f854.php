<?php

/* TwigBundle:Exception:error.atom.twig */
class __TwigTemplate_30766f159ba1e4039c12dffca9c0f2ae0bd215785ca6eb4d649cde8434c2cb65 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_43580c66f286e7162dcf0e25fa21621dab83521b25e706015141c98ecedcfb4a = $this->env->getExtension("native_profiler");
        $__internal_43580c66f286e7162dcf0e25fa21621dab83521b25e706015141c98ecedcfb4a->enter($__internal_43580c66f286e7162dcf0e25fa21621dab83521b25e706015141c98ecedcfb4a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.atom.twig"));

        // line 1
        $this->loadTemplate("TwigBundle:Exception:error.xml.twig", "TwigBundle:Exception:error.atom.twig", 1)->display($context);
        
        $__internal_43580c66f286e7162dcf0e25fa21621dab83521b25e706015141c98ecedcfb4a->leave($__internal_43580c66f286e7162dcf0e25fa21621dab83521b25e706015141c98ecedcfb4a_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.atom.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include 'TwigBundle:Exception:error.xml.twig' %}*/
/* */
