<?php

/* AppBundle:Default:index.html.twig */
class __TwigTemplate_159bdf7148dee0b40f3dce24aae89b8fd67ccc64dc9b0b1e9c2f2dff3568102c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("AppBundle::layout.html.twig", "AppBundle:Default:index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "AppBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e41af210862d6c1133abffb8e722435476ae082343595d708cc87d3e1dda84a9 = $this->env->getExtension("native_profiler");
        $__internal_e41af210862d6c1133abffb8e722435476ae082343595d708cc87d3e1dda84a9->enter($__internal_e41af210862d6c1133abffb8e722435476ae082343595d708cc87d3e1dda84a9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Default:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_e41af210862d6c1133abffb8e722435476ae082343595d708cc87d3e1dda84a9->leave($__internal_e41af210862d6c1133abffb8e722435476ae082343595d708cc87d3e1dda84a9_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_5b9a559f7ac7f3acf84c773cd3d6a2b956d06bddb07fc512cb6fb4cabb97a018 = $this->env->getExtension("native_profiler");
        $__internal_5b9a559f7ac7f3acf84c773cd3d6a2b956d06bddb07fc512cb6fb4cabb97a018->enter($__internal_5b9a559f7ac7f3acf84c773cd3d6a2b956d06bddb07fc512cb6fb4cabb97a018_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "


<div class=\"well\">
  <h3>Evennement encours :</h3><br />

</div>

<div class=\"well\">
  <h3>Evenement manuel :</h3>
  ";
        // line 14
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["eventForm"]) ? $context["eventForm"] : $this->getContext($context, "eventForm")), 'form', array("style" => "inline"));
        echo "
  <nav>
  <ul class=\"pager\">
    <li class=\"next\">
    <a href=\"javascript:void(0)\" id=\"";
        // line 18
        echo $this->env->getExtension('routing')->getPath("event_execute");
        echo "\" class=\"executeOperation\" >lancer l'evenement >></a>
    </li>
  </ul>
</nav>



</div>

<div class=\"btn-group-vertical\" role=\"group\" aria-label=\"...\">
  <button type=\"button\" class=\"btn btn-warning\" style=\"text-align: left;\">Bouton “Go” : Ecran Jaune</button>
  <button type=\"button\" class=\"btn btn-success\" style=\"text-align: left;\">Bouton “Go” : Ecran Vert</button>
  <button type=\"button\" class=\"btn btn-danger\" style=\"text-align: left;\">Bouton “Go” : Ecran Rouge</button>
  <button type=\"button\" class=\"btn label-default\" style=\"text-align: left;\">Bouton “Go” : Ecran Noir avec écrit en blanc “Batelier Records”.</button>
  <button type=\"button\" class=\"btn label-default\" style=\"text-align: left;\">Bouton “Go” : Bouton “Go” : Ecran blanc avec le logo de Batelier Records</button>
</div>


<table class=\"table table-hover\">
  <thead>
    <tr>
      <th>Firstname</th>
      <th>Lastname</th>
      <th>Email</th>
    </tr>
  </thead>
  <tbody>
    ";
        // line 45
        echo $this->env->getExtension('dump')->dump($this->env, $context, (isset($context["entities"]) ? $context["entities"] : $this->getContext($context, "entities")));
        echo "
";
        // line 46
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["entities"]) ? $context["entities"] : $this->getContext($context, "entities")));
        foreach ($context['_seq'] as $context["_key"] => $context["temp"]) {
            // line 47
            echo "<tr>
  <td>";
            // line 48
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "name", array()), "html", null, true);
            echo "</td>
  <td>";
            // line 49
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "description", array()), "html", null, true);
            echo "</td>
  <td><button type=\"submit\" class=\"btn btn-default\" style=\"float:right;\">Lancer cette sequence</button></td>
</tr>
<tr>
  <td></td>
  <td colspan=\"2\">
    <table class=\"table table-hover\">
        ";
            // line 56
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($context["temp"], "events", array()));
            foreach ($context['_seq'] as $context["_key"] => $context["temp1"]) {
                // line 57
                echo "        <tr>
          <td>";
                // line 58
                echo twig_escape_filter($this->env, $this->getAttribute($context["temp1"], "label", array()), "html", null, true);
                echo "</td>
          <td>";
                // line 59
                echo twig_escape_filter($this->env, $this->getAttribute($context["temp1"], "text", array()), "html", null, true);
                echo "</td>
          <td>";
                // line 60
                echo twig_escape_filter($this->env, $this->getAttribute($context["temp1"], "textcolor", array()), "html", null, true);
                echo "</td>
        </tr>
        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['temp1'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 63
            echo "    </table>
  </td>
</tr>
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['temp'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 67
        echo "  </tbody>
</table>
";
        
        $__internal_5b9a559f7ac7f3acf84c773cd3d6a2b956d06bddb07fc512cb6fb4cabb97a018->leave($__internal_5b9a559f7ac7f3acf84c773cd3d6a2b956d06bddb07fc512cb6fb4cabb97a018_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Default:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  147 => 67,  138 => 63,  129 => 60,  125 => 59,  121 => 58,  118 => 57,  114 => 56,  104 => 49,  100 => 48,  97 => 47,  93 => 46,  89 => 45,  59 => 18,  52 => 14,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'AppBundle::layout.html.twig' %}*/
/* */
/* {% block body %}*/
/* */
/* */
/* */
/* <div class="well">*/
/*   <h3>Evennement encours :</h3><br />*/
/* */
/* </div>*/
/* */
/* <div class="well">*/
/*   <h3>Evenement manuel :</h3>*/
/*   {{ form( eventForm, { 'style': 'inline' } ) }}*/
/*   <nav>*/
/*   <ul class="pager">*/
/*     <li class="next">*/
/*     <a href="javascript:void(0)" id="{{ path('event_execute') }}" class="executeOperation" >lancer l'evenement >></a>*/
/*     </li>*/
/*   </ul>*/
/* </nav>*/
/* */
/* */
/* */
/* </div>*/
/* */
/* <div class="btn-group-vertical" role="group" aria-label="...">*/
/*   <button type="button" class="btn btn-warning" style="text-align: left;">Bouton “Go” : Ecran Jaune</button>*/
/*   <button type="button" class="btn btn-success" style="text-align: left;">Bouton “Go” : Ecran Vert</button>*/
/*   <button type="button" class="btn btn-danger" style="text-align: left;">Bouton “Go” : Ecran Rouge</button>*/
/*   <button type="button" class="btn label-default" style="text-align: left;">Bouton “Go” : Ecran Noir avec écrit en blanc “Batelier Records”.</button>*/
/*   <button type="button" class="btn label-default" style="text-align: left;">Bouton “Go” : Bouton “Go” : Ecran blanc avec le logo de Batelier Records</button>*/
/* </div>*/
/* */
/* */
/* <table class="table table-hover">*/
/*   <thead>*/
/*     <tr>*/
/*       <th>Firstname</th>*/
/*       <th>Lastname</th>*/
/*       <th>Email</th>*/
/*     </tr>*/
/*   </thead>*/
/*   <tbody>*/
/*     {{dump(entities)}}*/
/* {% for temp in entities %}*/
/* <tr>*/
/*   <td>{{temp.name}}</td>*/
/*   <td>{{temp.description}}</td>*/
/*   <td><button type="submit" class="btn btn-default" style="float:right;">Lancer cette sequence</button></td>*/
/* </tr>*/
/* <tr>*/
/*   <td></td>*/
/*   <td colspan="2">*/
/*     <table class="table table-hover">*/
/*         {% for temp1 in temp.events %}*/
/*         <tr>*/
/*           <td>{{temp1.label}}</td>*/
/*           <td>{{temp1.text}}</td>*/
/*           <td>{{temp1.textcolor}}</td>*/
/*         </tr>*/
/*         {% endfor %}*/
/*     </table>*/
/*   </td>*/
/* </tr>*/
/* {% endfor %}*/
/*   </tbody>*/
/* </table>*/
/* {% endblock %}*/
/* */
