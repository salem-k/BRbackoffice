<?php

/* TwigBundle:Exception:error.css.twig */
class __TwigTemplate_9a55e204237bc5117f3d185cd74315399c8c02797cba1ab6af50d9ef28621772 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e72ee815671951a6cfe90a2882084a227811b77350af889788e1345a0fca72c4 = $this->env->getExtension("native_profiler");
        $__internal_e72ee815671951a6cfe90a2882084a227811b77350af889788e1345a0fca72c4->enter($__internal_e72ee815671951a6cfe90a2882084a227811b77350af889788e1345a0fca72c4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "css", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "css", null, true);
        echo "

*/
";
        
        $__internal_e72ee815671951a6cfe90a2882084a227811b77350af889788e1345a0fca72c4->leave($__internal_e72ee815671951a6cfe90a2882084a227811b77350af889788e1345a0fca72c4_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 2,  22 => 1,);
    }
}
/* /**/
/* {{ status_code }} {{ status_text }}*/
/* */
/* *//* */
/* */
