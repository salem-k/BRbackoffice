<?php

/* ::base.html.twig */
class __TwigTemplate_e6ac9e0673ef5272930be16e87b58ba8df1efd034a3f31bb2a0615975289e79b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a7934271960cdaf0de87e3539ac2cf697603b2c2c161e6d5f0a725e2cdd6e6c4 = $this->env->getExtension("native_profiler");
        $__internal_a7934271960cdaf0de87e3539ac2cf697603b2c2c161e6d5f0a725e2cdd6e6c4->enter($__internal_a7934271960cdaf0de87e3539ac2cf697603b2c2c161e6d5f0a725e2cdd6e6c4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        ";
        // line 10
        $this->displayBlock('body', $context, $blocks);
        // line 11
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 12
        echo "    </body>
</html>
";
        
        $__internal_a7934271960cdaf0de87e3539ac2cf697603b2c2c161e6d5f0a725e2cdd6e6c4->leave($__internal_a7934271960cdaf0de87e3539ac2cf697603b2c2c161e6d5f0a725e2cdd6e6c4_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_798ac7304a762c13fe82378014b9a60e402b5a0db9b44f05f992ceb7a2c43be6 = $this->env->getExtension("native_profiler");
        $__internal_798ac7304a762c13fe82378014b9a60e402b5a0db9b44f05f992ceb7a2c43be6->enter($__internal_798ac7304a762c13fe82378014b9a60e402b5a0db9b44f05f992ceb7a2c43be6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_798ac7304a762c13fe82378014b9a60e402b5a0db9b44f05f992ceb7a2c43be6->leave($__internal_798ac7304a762c13fe82378014b9a60e402b5a0db9b44f05f992ceb7a2c43be6_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_d6ea029885cba2b555cdcadaca80b6f8e16a9b776b4a2790d71a50df7c67325f = $this->env->getExtension("native_profiler");
        $__internal_d6ea029885cba2b555cdcadaca80b6f8e16a9b776b4a2790d71a50df7c67325f->enter($__internal_d6ea029885cba2b555cdcadaca80b6f8e16a9b776b4a2790d71a50df7c67325f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_d6ea029885cba2b555cdcadaca80b6f8e16a9b776b4a2790d71a50df7c67325f->leave($__internal_d6ea029885cba2b555cdcadaca80b6f8e16a9b776b4a2790d71a50df7c67325f_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_bfe5b5abd3049b2a6024050df0e2345b1b6d65d05f4f1d8b87f1a149ccfb0810 = $this->env->getExtension("native_profiler");
        $__internal_bfe5b5abd3049b2a6024050df0e2345b1b6d65d05f4f1d8b87f1a149ccfb0810->enter($__internal_bfe5b5abd3049b2a6024050df0e2345b1b6d65d05f4f1d8b87f1a149ccfb0810_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_bfe5b5abd3049b2a6024050df0e2345b1b6d65d05f4f1d8b87f1a149ccfb0810->leave($__internal_bfe5b5abd3049b2a6024050df0e2345b1b6d65d05f4f1d8b87f1a149ccfb0810_prof);

    }

    // line 11
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_7da0712a418b7ee9ea4668c59dbf9491e2f8e205d72ad69c3cbf3d17f452fe07 = $this->env->getExtension("native_profiler");
        $__internal_7da0712a418b7ee9ea4668c59dbf9491e2f8e205d72ad69c3cbf3d17f452fe07->enter($__internal_7da0712a418b7ee9ea4668c59dbf9491e2f8e205d72ad69c3cbf3d17f452fe07_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_7da0712a418b7ee9ea4668c59dbf9491e2f8e205d72ad69c3cbf3d17f452fe07->leave($__internal_7da0712a418b7ee9ea4668c59dbf9491e2f8e205d72ad69c3cbf3d17f452fe07_prof);

    }

    public function getTemplateName()
    {
        return "::base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  93 => 11,  82 => 10,  71 => 6,  59 => 5,  50 => 12,  47 => 11,  45 => 10,  38 => 7,  36 => 6,  32 => 5,  26 => 1,);
    }
}
/* <!DOCTYPE html>*/
/* <html>*/
/*     <head>*/
/*         <meta charset="UTF-8" />*/
/*         <title>{% block title %}Welcome!{% endblock %}</title>*/
/*         {% block stylesheets %}{% endblock %}*/
/*         <link rel="icon" type="image/x-icon" href="{{ asset('favicon.ico') }}" />*/
/*     </head>*/
/*     <body>*/
/*         {% block body %}{% endblock %}*/
/*         {% block javascripts %}{% endblock %}*/
/*     </body>*/
/* </html>*/
/* */
