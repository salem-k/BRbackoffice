<?php

/* BraincraftedBootstrapBundle::ie8-support.html.twig */
class __TwigTemplate_354dba1d5cee3443631dd982378c03ee392dce7d421eda9b6d0f4bcd5ed8d7fa extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ce67861c7ca64077ca53ddb46d0bd828378f21a7167cb2dbf5a32d4201ab45bc = $this->env->getExtension("native_profiler");
        $__internal_ce67861c7ca64077ca53ddb46d0bd828378f21a7167cb2dbf5a32d4201ab45bc->enter($__internal_ce67861c7ca64077ca53ddb46d0bd828378f21a7167cb2dbf5a32d4201ab45bc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "BraincraftedBootstrapBundle::ie8-support.html.twig"));

        // line 1
        echo "<!--[if lt IE 9]>
    <script src=\"https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv-printshiv.min.js\"></script>
    <script src=\"https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js\"></script>
<![endif]-->
";
        
        $__internal_ce67861c7ca64077ca53ddb46d0bd828378f21a7167cb2dbf5a32d4201ab45bc->leave($__internal_ce67861c7ca64077ca53ddb46d0bd828378f21a7167cb2dbf5a32d4201ab45bc_prof);

    }

    public function getTemplateName()
    {
        return "BraincraftedBootstrapBundle::ie8-support.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <!--[if lt IE 9]>*/
/*     <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv-printshiv.min.js"></script>*/
/*     <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>*/
/* <![endif]-->*/
/* */
