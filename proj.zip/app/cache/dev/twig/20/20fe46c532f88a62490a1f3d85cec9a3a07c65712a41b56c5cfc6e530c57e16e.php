<?php

/* BraincraftedBootstrapBundle::ie8-support.html.twig */
class __TwigTemplate_354dba1d5cee3443631dd982378c03ee392dce7d421eda9b6d0f4bcd5ed8d7fa extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0c4552f6392e67b8122cfd0a9045dab8ef6dcc59721271747ca8e81c7c791f74 = $this->env->getExtension("native_profiler");
        $__internal_0c4552f6392e67b8122cfd0a9045dab8ef6dcc59721271747ca8e81c7c791f74->enter($__internal_0c4552f6392e67b8122cfd0a9045dab8ef6dcc59721271747ca8e81c7c791f74_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "BraincraftedBootstrapBundle::ie8-support.html.twig"));

        // line 1
        echo "<!--[if lt IE 9]>
    <script src=\"https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv-printshiv.min.js\"></script>
    <script src=\"https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js\"></script>
<![endif]-->
";
        
        $__internal_0c4552f6392e67b8122cfd0a9045dab8ef6dcc59721271747ca8e81c7c791f74->leave($__internal_0c4552f6392e67b8122cfd0a9045dab8ef6dcc59721271747ca8e81c7c791f74_prof);

    }

    public function getTemplateName()
    {
        return "BraincraftedBootstrapBundle::ie8-support.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <!--[if lt IE 9]>*/
/*     <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv-printshiv.min.js"></script>*/
/*     <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>*/
/* <![endif]-->*/
/* */
