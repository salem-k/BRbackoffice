<?php

/* AppBundle:Event:new.html.twig */
class __TwigTemplate_928f0ebd13a8f7454a55f2af9918b65b54b2fa59fc7f25c017bee8808fe088f1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("AppBundle::layout.html.twig", "AppBundle:Event:new.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "AppBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4d68d0a760b6f991d53b0ec2f07c84f0aaae897eac379c629b3b77deb57e7f3b = $this->env->getExtension("native_profiler");
        $__internal_4d68d0a760b6f991d53b0ec2f07c84f0aaae897eac379c629b3b77deb57e7f3b->enter($__internal_4d68d0a760b6f991d53b0ec2f07c84f0aaae897eac379c629b3b77deb57e7f3b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Event:new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_4d68d0a760b6f991d53b0ec2f07c84f0aaae897eac379c629b3b77deb57e7f3b->leave($__internal_4d68d0a760b6f991d53b0ec2f07c84f0aaae897eac379c629b3b77deb57e7f3b_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_90975f0c6cde7bf173b13793ce6dc3dd43eed9eca535d3b8bee654d5128923a2 = $this->env->getExtension("native_profiler");
        $__internal_90975f0c6cde7bf173b13793ce6dc3dd43eed9eca535d3b8bee654d5128923a2->enter($__internal_90975f0c6cde7bf173b13793ce6dc3dd43eed9eca535d3b8bee654d5128923a2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "<h1>Event creation</h1>

    ";
        // line 6
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form');
        echo "

        <ul class=\"record_actions\">
    <li>
        <a href=\"";
        // line 10
        echo $this->env->getExtension('routing')->getPath("event");
        echo "\">
            Back to the list
        </a>
    </li>
</ul>
";
        
        $__internal_90975f0c6cde7bf173b13793ce6dc3dd43eed9eca535d3b8bee654d5128923a2->leave($__internal_90975f0c6cde7bf173b13793ce6dc3dd43eed9eca535d3b8bee654d5128923a2_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Event:new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  51 => 10,  44 => 6,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'AppBundle::layout.html.twig' %}*/
/* */
/* {% block body -%}*/
/*     <h1>Event creation</h1>*/
/* */
/*     {{ form(form) }}*/
/* */
/*         <ul class="record_actions">*/
/*     <li>*/
/*         <a href="{{ path('event') }}">*/
/*             Back to the list*/
/*         </a>*/
/*     </li>*/
/* </ul>*/
/* {% endblock %}*/
/* */
