<?php

/* AppBundle:Sequence:new.html.twig */
class __TwigTemplate_6b629116e002ed961638dea1ec83062ad69b9a609a0db8e6148296403cd590cb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("AppBundle::layout.html.twig", "AppBundle:Sequence:new.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "AppBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_aabe8f22d149080142b0ec1cb74a0f90f361260d64141fc16eed8300e14eefc9 = $this->env->getExtension("native_profiler");
        $__internal_aabe8f22d149080142b0ec1cb74a0f90f361260d64141fc16eed8300e14eefc9->enter($__internal_aabe8f22d149080142b0ec1cb74a0f90f361260d64141fc16eed8300e14eefc9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Sequence:new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_aabe8f22d149080142b0ec1cb74a0f90f361260d64141fc16eed8300e14eefc9->leave($__internal_aabe8f22d149080142b0ec1cb74a0f90f361260d64141fc16eed8300e14eefc9_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_af892ead067126e2f52d1554beb5c464edf85f3a7d4bd272bd692a334cea1df3 = $this->env->getExtension("native_profiler");
        $__internal_af892ead067126e2f52d1554beb5c464edf85f3a7d4bd272bd692a334cea1df3->enter($__internal_af892ead067126e2f52d1554beb5c464edf85f3a7d4bd272bd692a334cea1df3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "<h1>Sequence creation</h1>

    ";
        // line 6
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form');
        echo "

        <ul class=\"record_actions\">
    <li>
        <a href=\"";
        // line 10
        echo $this->env->getExtension('routing')->getPath("sequence");
        echo "\">
            Back to the list
        </a>
    </li>
</ul>
";
        
        $__internal_af892ead067126e2f52d1554beb5c464edf85f3a7d4bd272bd692a334cea1df3->leave($__internal_af892ead067126e2f52d1554beb5c464edf85f3a7d4bd272bd692a334cea1df3_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Sequence:new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  51 => 10,  44 => 6,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'AppBundle::layout.html.twig' %}*/
/* */
/* {% block body -%}*/
/*     <h1>Sequence creation</h1>*/
/* */
/*     {{ form(form) }}*/
/* */
/*         <ul class="record_actions">*/
/*     <li>*/
/*         <a href="{{ path('sequence') }}">*/
/*             Back to the list*/
/*         </a>*/
/*     </li>*/
/* </ul>*/
/* {% endblock %}*/
/* */
