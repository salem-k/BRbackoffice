<?php

/* TwigBundle:Exception:error.rdf.twig */
class __TwigTemplate_df24077c871c4e3ec2b4905102bb239c77387264607c05437c8034298224a068 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d3b0363610593cca9d531b5b87c712cc3cceab79b46091f591309afcd4f694e1 = $this->env->getExtension("native_profiler");
        $__internal_d3b0363610593cca9d531b5b87c712cc3cceab79b46091f591309afcd4f694e1->enter($__internal_d3b0363610593cca9d531b5b87c712cc3cceab79b46091f591309afcd4f694e1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.rdf.twig"));

        // line 1
        $this->loadTemplate("TwigBundle:Exception:error.xml.twig", "TwigBundle:Exception:error.rdf.twig", 1)->display($context);
        
        $__internal_d3b0363610593cca9d531b5b87c712cc3cceab79b46091f591309afcd4f694e1->leave($__internal_d3b0363610593cca9d531b5b87c712cc3cceab79b46091f591309afcd4f694e1_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.rdf.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include 'TwigBundle:Exception:error.xml.twig' %}*/
/* */
