<?php

/* TwigBundle:Exception:exception.atom.twig */
class __TwigTemplate_fa8c798c2c422a3f99a93364e5f40b7d5ffd9b4b700a3c080a7d3b91f278cb6c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_df75fdf7af4939b0639164ee9969fdfc0964f2bbd6a886331f1ae9def58cc35a = $this->env->getExtension("native_profiler");
        $__internal_df75fdf7af4939b0639164ee9969fdfc0964f2bbd6a886331f1ae9def58cc35a->enter($__internal_df75fdf7af4939b0639164ee9969fdfc0964f2bbd6a886331f1ae9def58cc35a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.atom.twig"));

        // line 1
        $this->loadTemplate("TwigBundle:Exception:exception.xml.twig", "TwigBundle:Exception:exception.atom.twig", 1)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        
        $__internal_df75fdf7af4939b0639164ee9969fdfc0964f2bbd6a886331f1ae9def58cc35a->leave($__internal_df75fdf7af4939b0639164ee9969fdfc0964f2bbd6a886331f1ae9def58cc35a_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include 'TwigBundle:Exception:exception.xml.twig' with { 'exception': exception } %}*/
/* */
