<?php

/* SensioDistributionBundle::Configurator/layout.html.twig */
class __TwigTemplate_528d5c3871b3431d55c23b642e3af8e58e681268eb9d9721482a32cfd4efccd2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("TwigBundle::layout.html.twig", "SensioDistributionBundle::Configurator/layout.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "TwigBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_43d274fc24fc52233cb71cb68b3fad2cb7a75120ef7f00179abc36affb7130ef = $this->env->getExtension("native_profiler");
        $__internal_43d274fc24fc52233cb71cb68b3fad2cb7a75120ef7f00179abc36affb7130ef->enter($__internal_43d274fc24fc52233cb71cb68b3fad2cb7a75120ef7f00179abc36affb7130ef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SensioDistributionBundle::Configurator/layout.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_43d274fc24fc52233cb71cb68b3fad2cb7a75120ef7f00179abc36affb7130ef->leave($__internal_43d274fc24fc52233cb71cb68b3fad2cb7a75120ef7f00179abc36affb7130ef_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_dd35f052ef6348eafb08d41fd2b0d4d012c978990a355b59001f1e54c39426ec = $this->env->getExtension("native_profiler");
        $__internal_dd35f052ef6348eafb08d41fd2b0d4d012c978990a355b59001f1e54c39426ec->enter($__internal_dd35f052ef6348eafb08d41fd2b0d4d012c978990a355b59001f1e54c39426ec_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/sensiodistribution/webconfigurator/css/configurator.css"), "html", null, true);
        echo "\" />
";
        
        $__internal_dd35f052ef6348eafb08d41fd2b0d4d012c978990a355b59001f1e54c39426ec->leave($__internal_dd35f052ef6348eafb08d41fd2b0d4d012c978990a355b59001f1e54c39426ec_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_a37f857b96c50925eca8e857b4678cfd5e681d8ae7731199657b792e0cf9d843 = $this->env->getExtension("native_profiler");
        $__internal_a37f857b96c50925eca8e857b4678cfd5e681d8ae7731199657b792e0cf9d843->enter($__internal_a37f857b96c50925eca8e857b4678cfd5e681d8ae7731199657b792e0cf9d843_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Web Configurator Bundle";
        
        $__internal_a37f857b96c50925eca8e857b4678cfd5e681d8ae7731199657b792e0cf9d843->leave($__internal_a37f857b96c50925eca8e857b4678cfd5e681d8ae7731199657b792e0cf9d843_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_7975c291688f66a7eb44fa82a8ddb64a2bc31783f664728f01ae3b14ea57387b = $this->env->getExtension("native_profiler");
        $__internal_7975c291688f66a7eb44fa82a8ddb64a2bc31783f664728f01ae3b14ea57387b->enter($__internal_7975c291688f66a7eb44fa82a8ddb64a2bc31783f664728f01ae3b14ea57387b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "    <div class=\"block\">
        ";
        // line 11
        $this->displayBlock('content', $context, $blocks);
        // line 12
        echo "    </div>
    <div class=\"version\">Symfony Standard Edition v.";
        // line 13
        echo twig_escape_filter($this->env, (isset($context["version"]) ? $context["version"] : $this->getContext($context, "version")), "html", null, true);
        echo "</div>
";
        
        $__internal_7975c291688f66a7eb44fa82a8ddb64a2bc31783f664728f01ae3b14ea57387b->leave($__internal_7975c291688f66a7eb44fa82a8ddb64a2bc31783f664728f01ae3b14ea57387b_prof);

    }

    // line 11
    public function block_content($context, array $blocks = array())
    {
        $__internal_a70f17de550ff0eaf963e20706c73a9b6e055a4809ac662f0cf72408e33ab6d6 = $this->env->getExtension("native_profiler");
        $__internal_a70f17de550ff0eaf963e20706c73a9b6e055a4809ac662f0cf72408e33ab6d6->enter($__internal_a70f17de550ff0eaf963e20706c73a9b6e055a4809ac662f0cf72408e33ab6d6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        
        $__internal_a70f17de550ff0eaf963e20706c73a9b6e055a4809ac662f0cf72408e33ab6d6->leave($__internal_a70f17de550ff0eaf963e20706c73a9b6e055a4809ac662f0cf72408e33ab6d6_prof);

    }

    public function getTemplateName()
    {
        return "SensioDistributionBundle::Configurator/layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  88 => 11,  79 => 13,  76 => 12,  74 => 11,  71 => 10,  65 => 9,  53 => 7,  43 => 4,  37 => 3,  11 => 1,);
    }
}
/* {% extends "TwigBundle::layout.html.twig" %}*/
/* */
/* {% block head %}*/
/*     <link rel="stylesheet" href="{{ asset('bundles/sensiodistribution/webconfigurator/css/configurator.css') }}" />*/
/* {% endblock %}*/
/* */
/* {% block title 'Web Configurator Bundle' %}*/
/* */
/* {% block body %}*/
/*     <div class="block">*/
/*         {% block content %}{% endblock %}*/
/*     </div>*/
/*     <div class="version">Symfony Standard Edition v.{{ version }}</div>*/
/* {% endblock %}*/
/* */
