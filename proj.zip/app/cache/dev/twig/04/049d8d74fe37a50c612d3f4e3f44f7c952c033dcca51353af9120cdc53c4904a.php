<?php

/* AppBundle:Event:index.html.twig */
class __TwigTemplate_4e8065268f9563dba120c35fe62dd36b8445bb071bf9e2fda89846dd7e0d1dc9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("AppBundle::layout.html.twig", "AppBundle:Event:index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "AppBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f2f3b1091ce1db69360b5e56724f2b8da2f49bafb9b8af3ed2e01260066bcf5a = $this->env->getExtension("native_profiler");
        $__internal_f2f3b1091ce1db69360b5e56724f2b8da2f49bafb9b8af3ed2e01260066bcf5a->enter($__internal_f2f3b1091ce1db69360b5e56724f2b8da2f49bafb9b8af3ed2e01260066bcf5a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Event:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f2f3b1091ce1db69360b5e56724f2b8da2f49bafb9b8af3ed2e01260066bcf5a->leave($__internal_f2f3b1091ce1db69360b5e56724f2b8da2f49bafb9b8af3ed2e01260066bcf5a_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_01d84eade9aa7670558c583bcfb73bef0c97d1ed204e092c4d26ef0b5a036af0 = $this->env->getExtension("native_profiler");
        $__internal_01d84eade9aa7670558c583bcfb73bef0c97d1ed204e092c4d26ef0b5a036af0->enter($__internal_01d84eade9aa7670558c583bcfb73bef0c97d1ed204e092c4d26ef0b5a036af0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "<h1>Event list</h1>

    <table class=\"records_list\">
        <thead>
            <tr>
                <th>Id</th>
                <th>Label</th>
                <th>Text</th>
                <th>Textcolor</th>
                <th>Bgcolor</th>
                <th>Image</th>
                <th>Sound</th>
                <th>Time</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        ";
        // line 21
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["entities"]) ? $context["entities"] : $this->getContext($context, "entities")));
        foreach ($context['_seq'] as $context["_key"] => $context["entity"]) {
            // line 22
            echo "            <tr>
                <td><a href=\"";
            // line 23
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("event_show", array("id" => $this->getAttribute($context["entity"], "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["entity"], "id", array()), "html", null, true);
            echo "</a></td>
                <td>";
            // line 24
            echo twig_escape_filter($this->env, $this->getAttribute($context["entity"], "label", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute($context["entity"], "text", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 26
            echo twig_escape_filter($this->env, $this->getAttribute($context["entity"], "textcolor", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 27
            echo twig_escape_filter($this->env, $this->getAttribute($context["entity"], "bgcolor", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 28
            echo twig_escape_filter($this->env, $this->getAttribute($context["entity"], "image", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 29
            echo twig_escape_filter($this->env, $this->getAttribute($context["entity"], "sound", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 30
            echo twig_escape_filter($this->env, $this->getAttribute($context["entity"], "time", array()), "html", null, true);
            echo "</td>
                <td>
                <ul>
                    <li>
                        <a href=\"";
            // line 34
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("event_show", array("id" => $this->getAttribute($context["entity"], "id", array()))), "html", null, true);
            echo "\">show</a>
                    </li>
                    <li>
                        <a href=\"";
            // line 37
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("event_edit", array("id" => $this->getAttribute($context["entity"], "id", array()))), "html", null, true);
            echo "\">edit</a>
                    </li>
                </ul>
                </td>
            </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['entity'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 43
        echo "        </tbody>
    </table>

        <ul>
        <li>
            <a href=\"";
        // line 48
        echo $this->env->getExtension('routing')->getPath("event_new");
        echo "\">
                Create a new entry
            </a>
        </li>
    </ul>
    ";
        
        $__internal_01d84eade9aa7670558c583bcfb73bef0c97d1ed204e092c4d26ef0b5a036af0->leave($__internal_01d84eade9aa7670558c583bcfb73bef0c97d1ed204e092c4d26ef0b5a036af0_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Event:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  128 => 48,  121 => 43,  109 => 37,  103 => 34,  96 => 30,  92 => 29,  88 => 28,  84 => 27,  80 => 26,  76 => 25,  72 => 24,  66 => 23,  63 => 22,  59 => 21,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'AppBundle::layout.html.twig' %}*/
/* */
/* {% block body -%}*/
/*     <h1>Event list</h1>*/
/* */
/*     <table class="records_list">*/
/*         <thead>*/
/*             <tr>*/
/*                 <th>Id</th>*/
/*                 <th>Label</th>*/
/*                 <th>Text</th>*/
/*                 <th>Textcolor</th>*/
/*                 <th>Bgcolor</th>*/
/*                 <th>Image</th>*/
/*                 <th>Sound</th>*/
/*                 <th>Time</th>*/
/*                 <th>Actions</th>*/
/*             </tr>*/
/*         </thead>*/
/*         <tbody>*/
/*         {% for entity in entities %}*/
/*             <tr>*/
/*                 <td><a href="{{ path('event_show', { 'id': entity.id }) }}">{{ entity.id }}</a></td>*/
/*                 <td>{{ entity.label }}</td>*/
/*                 <td>{{ entity.text }}</td>*/
/*                 <td>{{ entity.textcolor }}</td>*/
/*                 <td>{{ entity.bgcolor }}</td>*/
/*                 <td>{{ entity.image }}</td>*/
/*                 <td>{{ entity.sound }}</td>*/
/*                 <td>{{ entity.time }}</td>*/
/*                 <td>*/
/*                 <ul>*/
/*                     <li>*/
/*                         <a href="{{ path('event_show', { 'id': entity.id }) }}">show</a>*/
/*                     </li>*/
/*                     <li>*/
/*                         <a href="{{ path('event_edit', { 'id': entity.id }) }}">edit</a>*/
/*                     </li>*/
/*                 </ul>*/
/*                 </td>*/
/*             </tr>*/
/*         {% endfor %}*/
/*         </tbody>*/
/*     </table>*/
/* */
/*         <ul>*/
/*         <li>*/
/*             <a href="{{ path('event_new') }}">*/
/*                 Create a new entry*/
/*             </a>*/
/*         </li>*/
/*     </ul>*/
/*     {% endblock %}*/
/* */
