<?php

/* AppBundle:Event:edit.html.twig */
class __TwigTemplate_b4c5d2d98148c64c94ee030d20ce911fab54f01d51c7c3eba533f450ad3c1b38 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("AppBundle::layout.html.twig", "AppBundle:Event:edit.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "AppBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_618e315aaf28f84384b1446643af114f66f03d621e956f91b4a261721fa5aa18 = $this->env->getExtension("native_profiler");
        $__internal_618e315aaf28f84384b1446643af114f66f03d621e956f91b4a261721fa5aa18->enter($__internal_618e315aaf28f84384b1446643af114f66f03d621e956f91b4a261721fa5aa18_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Event:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_618e315aaf28f84384b1446643af114f66f03d621e956f91b4a261721fa5aa18->leave($__internal_618e315aaf28f84384b1446643af114f66f03d621e956f91b4a261721fa5aa18_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_4b784b1a66db31d0fff13630935e11be6f70af0fe5865b4fe277f686baa558cd = $this->env->getExtension("native_profiler");
        $__internal_4b784b1a66db31d0fff13630935e11be6f70af0fe5865b4fe277f686baa558cd->enter($__internal_4b784b1a66db31d0fff13630935e11be6f70af0fe5865b4fe277f686baa558cd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "<h1>Event edit</h1>

    ";
        // line 6
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'form');
        echo "

        <ul class=\"record_actions\">
    <li>
        <a href=\"";
        // line 10
        echo $this->env->getExtension('routing')->getPath("event");
        echo "\">
            Back to the list
        </a>
    </li>
    <li>";
        // line 14
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form');
        echo "</li>
</ul>
";
        
        $__internal_4b784b1a66db31d0fff13630935e11be6f70af0fe5865b4fe277f686baa558cd->leave($__internal_4b784b1a66db31d0fff13630935e11be6f70af0fe5865b4fe277f686baa558cd_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Event:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  58 => 14,  51 => 10,  44 => 6,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'AppBundle::layout.html.twig' %}*/
/* */
/* {% block body -%}*/
/*     <h1>Event edit</h1>*/
/* */
/*     {{ form(edit_form) }}*/
/* */
/*         <ul class="record_actions">*/
/*     <li>*/
/*         <a href="{{ path('event') }}">*/
/*             Back to the list*/
/*         </a>*/
/*     </li>*/
/*     <li>{{ form(delete_form) }}</li>*/
/* </ul>*/
/* {% endblock %}*/
/* */
