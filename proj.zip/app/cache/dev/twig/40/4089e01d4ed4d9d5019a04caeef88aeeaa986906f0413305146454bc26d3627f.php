<?php

/* BraincraftedBootstrapBundle::layout.html.twig */
class __TwigTemplate_95d9c8e22249da917f2cd11c54983492a6ec013af591a41c6b5b17504c1cd378 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'head' => array($this, 'block_head'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5b1f2a6548cd0035b54ba971481be9a9496667721c8a193c2b04422f5f3ffb8a = $this->env->getExtension("native_profiler");
        $__internal_5b1f2a6548cd0035b54ba971481be9a9496667721c8a193c2b04422f5f3ffb8a->enter($__internal_5b1f2a6548cd0035b54ba971481be9a9496667721c8a193c2b04422f5f3ffb8a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "BraincraftedBootstrapBundle::layout.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>

<head>

<title>";
        // line 6
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">

<!-- Bootstrap -->
<link href=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("/css/bootstrap.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" media=\"screen\">

";
        // line 12
        $this->displayBlock('head', $context, $blocks);
        // line 13
        echo "
</head>

<body>

";
        // line 18
        $this->displayBlock('body', $context, $blocks);
        // line 19
        echo "
<!-- JavaScript plugins (requires jQuery) -->
<script src=\"//code.jquery.com/jquery.js\"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src=\"";
        // line 23
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("/js/bootstrap.js"), "html", null, true);
        echo "\"></script>

<!-- Optionally enable responsive features in IE8 -->
<script src=\"js/respond.js\"></script>

</body>
</html>
";
        
        $__internal_5b1f2a6548cd0035b54ba971481be9a9496667721c8a193c2b04422f5f3ffb8a->leave($__internal_5b1f2a6548cd0035b54ba971481be9a9496667721c8a193c2b04422f5f3ffb8a_prof);

    }

    // line 6
    public function block_title($context, array $blocks = array())
    {
        $__internal_8785a22a63ab1def5adbf7e166e82c74a9012b7b8f25c6e516b1652ce6e63e4b = $this->env->getExtension("native_profiler");
        $__internal_8785a22a63ab1def5adbf7e166e82c74a9012b7b8f25c6e516b1652ce6e63e4b->enter($__internal_8785a22a63ab1def5adbf7e166e82c74a9012b7b8f25c6e516b1652ce6e63e4b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "BraincraftedBootstrapBundle by Florian Eckerstorfer";
        
        $__internal_8785a22a63ab1def5adbf7e166e82c74a9012b7b8f25c6e516b1652ce6e63e4b->leave($__internal_8785a22a63ab1def5adbf7e166e82c74a9012b7b8f25c6e516b1652ce6e63e4b_prof);

    }

    // line 12
    public function block_head($context, array $blocks = array())
    {
        $__internal_dfe1d1b2420fc9c5d9b4eca054c0bba569054e041d02368fd81498951b60c6bf = $this->env->getExtension("native_profiler");
        $__internal_dfe1d1b2420fc9c5d9b4eca054c0bba569054e041d02368fd81498951b60c6bf->enter($__internal_dfe1d1b2420fc9c5d9b4eca054c0bba569054e041d02368fd81498951b60c6bf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        
        $__internal_dfe1d1b2420fc9c5d9b4eca054c0bba569054e041d02368fd81498951b60c6bf->leave($__internal_dfe1d1b2420fc9c5d9b4eca054c0bba569054e041d02368fd81498951b60c6bf_prof);

    }

    // line 18
    public function block_body($context, array $blocks = array())
    {
        $__internal_e0953a95724b210b2c1475eef07e7d702dd40da4318a730e5408d37c0b7b4201 = $this->env->getExtension("native_profiler");
        $__internal_e0953a95724b210b2c1475eef07e7d702dd40da4318a730e5408d37c0b7b4201->enter($__internal_e0953a95724b210b2c1475eef07e7d702dd40da4318a730e5408d37c0b7b4201_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_e0953a95724b210b2c1475eef07e7d702dd40da4318a730e5408d37c0b7b4201->leave($__internal_e0953a95724b210b2c1475eef07e7d702dd40da4318a730e5408d37c0b7b4201_prof);

    }

    public function getTemplateName()
    {
        return "BraincraftedBootstrapBundle::layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  99 => 18,  88 => 12,  76 => 6,  61 => 23,  55 => 19,  53 => 18,  46 => 13,  44 => 12,  39 => 10,  32 => 6,  25 => 1,);
    }
}
/* <!DOCTYPE html>*/
/* <html>*/
/* */
/* <head>*/
/* */
/* <title>{% block title %}BraincraftedBootstrapBundle by Florian Eckerstorfer{% endblock title %}</title>*/
/* <meta name="viewport" content="width=device-width, initial-scale=1.0">*/
/* */
/* <!-- Bootstrap -->*/
/* <link href="{{ asset('/css/bootstrap.css') }}" rel="stylesheet" media="screen">*/
/* */
/* {% block head %}{% endblock %}*/
/* */
/* </head>*/
/* */
/* <body>*/
/* */
/* {% block body %}{% endblock body %}*/
/* */
/* <!-- JavaScript plugins (requires jQuery) -->*/
/* <script src="//code.jquery.com/jquery.js"></script>*/
/* <!-- Include all compiled plugins (below), or include individual files as needed -->*/
/* <script src="{{ asset('/js/bootstrap.js') }}"></script>*/
/* */
/* <!-- Optionally enable responsive features in IE8 -->*/
/* <script src="js/respond.js"></script>*/
/* */
/* </body>*/
/* </html>*/
/* */
