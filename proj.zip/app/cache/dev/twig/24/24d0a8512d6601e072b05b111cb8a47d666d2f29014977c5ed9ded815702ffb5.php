<?php

/* TwigBundle:Exception:error.js.twig */
class __TwigTemplate_a289d5f19a8c465b6dd0bc2b28392d6c4bc4a54005e9a75168b7ccd6061a0de2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d21e172f1d092bae4b9f434fd46a30db07218c02486a2c36f262f99c4934d78f = $this->env->getExtension("native_profiler");
        $__internal_d21e172f1d092bae4b9f434fd46a30db07218c02486a2c36f262f99c4934d78f->enter($__internal_d21e172f1d092bae4b9f434fd46a30db07218c02486a2c36f262f99c4934d78f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "js", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "js", null, true);
        echo "

*/
";
        
        $__internal_d21e172f1d092bae4b9f434fd46a30db07218c02486a2c36f262f99c4934d78f->leave($__internal_d21e172f1d092bae4b9f434fd46a30db07218c02486a2c36f262f99c4934d78f_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 2,  22 => 1,);
    }
}
/* /**/
/* {{ status_code }} {{ status_text }}*/
/* */
/* *//* */
/* */
