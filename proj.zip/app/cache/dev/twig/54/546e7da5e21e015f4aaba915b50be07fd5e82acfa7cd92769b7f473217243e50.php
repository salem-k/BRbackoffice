<?php

/* TwigBundle:Exception:exception.json.twig */
class __TwigTemplate_6258dd85f8858cb1ed9a3ca9fe83fa5a21a50c088200ee28ba4ed95cdf452469 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3b0d284a794fe953bceb27ec573545deb57deb68758f06b6f8ac8f651d0d89b5 = $this->env->getExtension("native_profiler");
        $__internal_3b0d284a794fe953bceb27ec573545deb57deb68758f06b6f8ac8f651d0d89b5->enter($__internal_3b0d284a794fe953bceb27ec573545deb57deb68758f06b6f8ac8f651d0d89b5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.json.twig"));

        // line 1
        echo twig_jsonencode_filter(array("error" => array("code" => (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "message" => (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "exception" => $this->getAttribute((isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")), "toarray", array()))));
        echo "
";
        
        $__internal_3b0d284a794fe953bceb27ec573545deb57deb68758f06b6f8ac8f651d0d89b5->leave($__internal_3b0d284a794fe953bceb27ec573545deb57deb68758f06b6f8ac8f651d0d89b5_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {{ { 'error': { 'code': status_code, 'message': status_text, 'exception': exception.toarray } }|json_encode|raw }}*/
/* */
