<?php

/* WebProfilerBundle:Profiler:ajax_layout.html.twig */
class __TwigTemplate_88ddf82120e8565338cb4bf05c8f3b87db0c9e46957b6b38fe5cd5a297e5339b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6c63901c7a699d5a5e901cd421b8f98cec67b47b67765aaceea1206218d09f25 = $this->env->getExtension("native_profiler");
        $__internal_6c63901c7a699d5a5e901cd421b8f98cec67b47b67765aaceea1206218d09f25->enter($__internal_6c63901c7a699d5a5e901cd421b8f98cec67b47b67765aaceea1206218d09f25_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_6c63901c7a699d5a5e901cd421b8f98cec67b47b67765aaceea1206218d09f25->leave($__internal_6c63901c7a699d5a5e901cd421b8f98cec67b47b67765aaceea1206218d09f25_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_e5def501c9ebab5b5ca0e270852262acd2bc57173cd3ea1f83ab0e503f4cb9c4 = $this->env->getExtension("native_profiler");
        $__internal_e5def501c9ebab5b5ca0e270852262acd2bc57173cd3ea1f83ab0e503f4cb9c4->enter($__internal_e5def501c9ebab5b5ca0e270852262acd2bc57173cd3ea1f83ab0e503f4cb9c4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_e5def501c9ebab5b5ca0e270852262acd2bc57173cd3ea1f83ab0e503f4cb9c4->leave($__internal_e5def501c9ebab5b5ca0e270852262acd2bc57173cd3ea1f83ab0e503f4cb9c4_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }
}
/* {% block panel '' %}*/
/* */
