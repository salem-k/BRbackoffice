<?php

/* TwigBundle:Exception:exception.rdf.twig */
class __TwigTemplate_a0e3292399552bb617ed9af5b2c9725b5a072b3ca963e22cdaab23460728de35 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_af83ee3b18a4dbfa9702575dcab582898d871fc0bdde8783558468d5d71aeb91 = $this->env->getExtension("native_profiler");
        $__internal_af83ee3b18a4dbfa9702575dcab582898d871fc0bdde8783558468d5d71aeb91->enter($__internal_af83ee3b18a4dbfa9702575dcab582898d871fc0bdde8783558468d5d71aeb91_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.rdf.twig"));

        // line 1
        $this->loadTemplate("TwigBundle:Exception:exception.xml.twig", "TwigBundle:Exception:exception.rdf.twig", 1)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        
        $__internal_af83ee3b18a4dbfa9702575dcab582898d871fc0bdde8783558468d5d71aeb91->leave($__internal_af83ee3b18a4dbfa9702575dcab582898d871fc0bdde8783558468d5d71aeb91_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include 'TwigBundle:Exception:exception.xml.twig' with { 'exception': exception } %}*/
/* */
