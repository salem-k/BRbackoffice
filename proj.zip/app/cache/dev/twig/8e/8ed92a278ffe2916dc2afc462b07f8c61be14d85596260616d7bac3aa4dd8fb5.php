<?php

/* TwigBundle:Exception:error.js.twig */
class __TwigTemplate_b79016b135f844f9b3b7dd066487b44ddcbb07cd52dd3ce5b922a4237cbb4607 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ed3fcaf3ae275efa652239506be3d7f08f0434519a2db849fe3ea0ad7698a734 = $this->env->getExtension("native_profiler");
        $__internal_ed3fcaf3ae275efa652239506be3d7f08f0434519a2db849fe3ea0ad7698a734->enter($__internal_ed3fcaf3ae275efa652239506be3d7f08f0434519a2db849fe3ea0ad7698a734_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "js", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "js", null, true);
        echo "

*/
";
        
        $__internal_ed3fcaf3ae275efa652239506be3d7f08f0434519a2db849fe3ea0ad7698a734->leave($__internal_ed3fcaf3ae275efa652239506be3d7f08f0434519a2db849fe3ea0ad7698a734_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 2,  22 => 1,);
    }
}
/* /**/
/* {{ status_code }} {{ status_text }}*/
/* */
/* *//* */
/* */
