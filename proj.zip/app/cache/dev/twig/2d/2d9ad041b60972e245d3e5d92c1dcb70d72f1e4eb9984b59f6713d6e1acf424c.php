<?php

/* TwigBundle:Exception:error.rdf.twig */
class __TwigTemplate_07801ca2093aaf5a0d315cd059b998b40f9b4cd38a80a34485e65fb272b6b2e8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9fb1a221e232d9845352ce53e323329b833935141d333200d8fbbf87e9c8a8a3 = $this->env->getExtension("native_profiler");
        $__internal_9fb1a221e232d9845352ce53e323329b833935141d333200d8fbbf87e9c8a8a3->enter($__internal_9fb1a221e232d9845352ce53e323329b833935141d333200d8fbbf87e9c8a8a3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.rdf.twig"));

        // line 1
        $this->loadTemplate("TwigBundle:Exception:error.xml.twig", "TwigBundle:Exception:error.rdf.twig", 1)->display($context);
        
        $__internal_9fb1a221e232d9845352ce53e323329b833935141d333200d8fbbf87e9c8a8a3->leave($__internal_9fb1a221e232d9845352ce53e323329b833935141d333200d8fbbf87e9c8a8a3_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.rdf.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include 'TwigBundle:Exception:error.xml.twig' %}*/
/* */
