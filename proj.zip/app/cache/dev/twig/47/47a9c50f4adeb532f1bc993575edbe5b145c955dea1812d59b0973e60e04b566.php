<?php

/* WebProfilerBundle:Profiler:ajax_layout.html.twig */
class __TwigTemplate_b669283cb7488a842ed99db036d2fb21c63c9d16d5fcbf5587678c079770d0ae extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7ccd1db86306586b8bde5e74a6788a76ed1de7ca5be099c275992ce339e8b7cc = $this->env->getExtension("native_profiler");
        $__internal_7ccd1db86306586b8bde5e74a6788a76ed1de7ca5be099c275992ce339e8b7cc->enter($__internal_7ccd1db86306586b8bde5e74a6788a76ed1de7ca5be099c275992ce339e8b7cc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_7ccd1db86306586b8bde5e74a6788a76ed1de7ca5be099c275992ce339e8b7cc->leave($__internal_7ccd1db86306586b8bde5e74a6788a76ed1de7ca5be099c275992ce339e8b7cc_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_98e9099f732ee2da668066e64b5d9685c0943db30c3b72b4f56405bfbd9bff91 = $this->env->getExtension("native_profiler");
        $__internal_98e9099f732ee2da668066e64b5d9685c0943db30c3b72b4f56405bfbd9bff91->enter($__internal_98e9099f732ee2da668066e64b5d9685c0943db30c3b72b4f56405bfbd9bff91_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_98e9099f732ee2da668066e64b5d9685c0943db30c3b72b4f56405bfbd9bff91->leave($__internal_98e9099f732ee2da668066e64b5d9685c0943db30c3b72b4f56405bfbd9bff91_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }
}
/* {% block panel '' %}*/
/* */
