<?php

/* SensioDistributionBundle::Configurator/layout.html.twig */
class __TwigTemplate_3b33af1139d73e3568dd44a48bb5875fe518414b1f634c5a3932bd5835ff5fdd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("TwigBundle::layout.html.twig", "SensioDistributionBundle::Configurator/layout.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "TwigBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_896e507ceb861136353207b16695fc7a8afe85a99d38371344d70c31c74c1a1e = $this->env->getExtension("native_profiler");
        $__internal_896e507ceb861136353207b16695fc7a8afe85a99d38371344d70c31c74c1a1e->enter($__internal_896e507ceb861136353207b16695fc7a8afe85a99d38371344d70c31c74c1a1e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SensioDistributionBundle::Configurator/layout.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_896e507ceb861136353207b16695fc7a8afe85a99d38371344d70c31c74c1a1e->leave($__internal_896e507ceb861136353207b16695fc7a8afe85a99d38371344d70c31c74c1a1e_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_98397f8643c7493e5d679829ebd7e67d53a779ea69cee7f198338bdf93a389b3 = $this->env->getExtension("native_profiler");
        $__internal_98397f8643c7493e5d679829ebd7e67d53a779ea69cee7f198338bdf93a389b3->enter($__internal_98397f8643c7493e5d679829ebd7e67d53a779ea69cee7f198338bdf93a389b3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/sensiodistribution/webconfigurator/css/configurator.css"), "html", null, true);
        echo "\" />
";
        
        $__internal_98397f8643c7493e5d679829ebd7e67d53a779ea69cee7f198338bdf93a389b3->leave($__internal_98397f8643c7493e5d679829ebd7e67d53a779ea69cee7f198338bdf93a389b3_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_a4bbfd14fb7e41adbac83ba2aad8fc2bb0a3a285d0c65d69cf36ac54ffd65101 = $this->env->getExtension("native_profiler");
        $__internal_a4bbfd14fb7e41adbac83ba2aad8fc2bb0a3a285d0c65d69cf36ac54ffd65101->enter($__internal_a4bbfd14fb7e41adbac83ba2aad8fc2bb0a3a285d0c65d69cf36ac54ffd65101_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Web Configurator Bundle";
        
        $__internal_a4bbfd14fb7e41adbac83ba2aad8fc2bb0a3a285d0c65d69cf36ac54ffd65101->leave($__internal_a4bbfd14fb7e41adbac83ba2aad8fc2bb0a3a285d0c65d69cf36ac54ffd65101_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_b8b07bf5a559abf2f2c49516687cde2919178f80f34ceec7d98c900c1ce699a2 = $this->env->getExtension("native_profiler");
        $__internal_b8b07bf5a559abf2f2c49516687cde2919178f80f34ceec7d98c900c1ce699a2->enter($__internal_b8b07bf5a559abf2f2c49516687cde2919178f80f34ceec7d98c900c1ce699a2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "    <div class=\"block\">
        ";
        // line 11
        $this->displayBlock('content', $context, $blocks);
        // line 12
        echo "    </div>
    <div class=\"version\">Symfony Standard Edition v.";
        // line 13
        echo twig_escape_filter($this->env, (isset($context["version"]) ? $context["version"] : $this->getContext($context, "version")), "html", null, true);
        echo "</div>
";
        
        $__internal_b8b07bf5a559abf2f2c49516687cde2919178f80f34ceec7d98c900c1ce699a2->leave($__internal_b8b07bf5a559abf2f2c49516687cde2919178f80f34ceec7d98c900c1ce699a2_prof);

    }

    // line 11
    public function block_content($context, array $blocks = array())
    {
        $__internal_9ec9e2ea0e8cca32c553eea9891747c2c693aef1085a0bcb458d318100221271 = $this->env->getExtension("native_profiler");
        $__internal_9ec9e2ea0e8cca32c553eea9891747c2c693aef1085a0bcb458d318100221271->enter($__internal_9ec9e2ea0e8cca32c553eea9891747c2c693aef1085a0bcb458d318100221271_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        
        $__internal_9ec9e2ea0e8cca32c553eea9891747c2c693aef1085a0bcb458d318100221271->leave($__internal_9ec9e2ea0e8cca32c553eea9891747c2c693aef1085a0bcb458d318100221271_prof);

    }

    public function getTemplateName()
    {
        return "SensioDistributionBundle::Configurator/layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  88 => 11,  79 => 13,  76 => 12,  74 => 11,  71 => 10,  65 => 9,  53 => 7,  43 => 4,  37 => 3,  11 => 1,);
    }
}
/* {% extends "TwigBundle::layout.html.twig" %}*/
/* */
/* {% block head %}*/
/*     <link rel="stylesheet" href="{{ asset('bundles/sensiodistribution/webconfigurator/css/configurator.css') }}" />*/
/* {% endblock %}*/
/* */
/* {% block title 'Web Configurator Bundle' %}*/
/* */
/* {% block body %}*/
/*     <div class="block">*/
/*         {% block content %}{% endblock %}*/
/*     </div>*/
/*     <div class="version">Symfony Standard Edition v.{{ version }}</div>*/
/* {% endblock %}*/
/* */
