<?php

/* AppBundle::layout.html.twig */
class __TwigTemplate_c5bc303390b85afcadd3dab93ede4298cdd1f1c7d83f0c78d341f563515d10cc extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d8ed33b5f253bd4cdbe34eebb567301728a5290ed7014e9cd771c1b73c57f211 = $this->env->getExtension("native_profiler");
        $__internal_d8ed33b5f253bd4cdbe34eebb567301728a5290ed7014e9cd771c1b73c57f211->enter($__internal_d8ed33b5f253bd4cdbe34eebb567301728a5290ed7014e9cd771c1b73c57f211_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle::layout.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
<head>

    <title>Batelier-Records ConcertManager BackOffice</title>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
    <!-- Bootstrap -->
    <link href=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("css/bootstrap.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" media=\"screen\">

    <!-- HTML5 Shim and Respond.js add IE8 support of HTML5 elements and media queries -->
    ";
        // line 11
        $this->loadTemplate("BraincraftedBootstrapBundle::ie8-support.html.twig", "AppBundle::layout.html.twig", 11)->display($context);
        // line 12
        echo "
</head>

<body>

  ";
        // line 17
        $this->displayBlock('body', $context, $blocks);
        // line 19
        echo "    <!-- jQuery (necessary for Bootstraps JavaScript plugins) -->
    <script src=\"";
        // line 20
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("js/jquery.js"), "html", null, true);
        echo "\"></script>
    <!-- Include all JavaScripts, compiled by Assetic -->
    <script src=\"";
        // line 22
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("js/bootstrap.js"), "html", null, true);
        echo "\"></script>
    ";
        // line 23
        $this->displayBlock('javascripts', $context, $blocks);
        // line 26
        echo "</body>
</html>
";
        
        $__internal_d8ed33b5f253bd4cdbe34eebb567301728a5290ed7014e9cd771c1b73c57f211->leave($__internal_d8ed33b5f253bd4cdbe34eebb567301728a5290ed7014e9cd771c1b73c57f211_prof);

    }

    // line 17
    public function block_body($context, array $blocks = array())
    {
        $__internal_182781383ceb1bbe3d92a0cd68b12cd2218775ec8084ee659b0c8c02969a8805 = $this->env->getExtension("native_profiler");
        $__internal_182781383ceb1bbe3d92a0cd68b12cd2218775ec8084ee659b0c8c02969a8805->enter($__internal_182781383ceb1bbe3d92a0cd68b12cd2218775ec8084ee659b0c8c02969a8805_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 18
        echo "  ";
        
        $__internal_182781383ceb1bbe3d92a0cd68b12cd2218775ec8084ee659b0c8c02969a8805->leave($__internal_182781383ceb1bbe3d92a0cd68b12cd2218775ec8084ee659b0c8c02969a8805_prof);

    }

    // line 23
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_857064e9bc162c5dd657109acec263426ebdeb7278bb7d4b57bb2bd0c66cb542 = $this->env->getExtension("native_profiler");
        $__internal_857064e9bc162c5dd657109acec263426ebdeb7278bb7d4b57bb2bd0c66cb542->enter($__internal_857064e9bc162c5dd657109acec263426ebdeb7278bb7d4b57bb2bd0c66cb542_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 24
        echo "
";
        
        $__internal_857064e9bc162c5dd657109acec263426ebdeb7278bb7d4b57bb2bd0c66cb542->leave($__internal_857064e9bc162c5dd657109acec263426ebdeb7278bb7d4b57bb2bd0c66cb542_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle::layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  92 => 24,  86 => 23,  79 => 18,  73 => 17,  64 => 26,  62 => 23,  58 => 22,  53 => 20,  50 => 19,  48 => 17,  41 => 12,  39 => 11,  33 => 8,  24 => 1,);
    }
}
/* <!DOCTYPE html>*/
/* <html>*/
/* <head>*/
/* */
/*     <title>Batelier-Records ConcertManager BackOffice</title>*/
/*     <meta name="viewport" content="width=device-width, initial-scale=1.0">*/
/*     <!-- Bootstrap -->*/
/*     <link href="{{ asset('css/bootstrap.css') }}" rel="stylesheet" media="screen">*/
/* */
/*     <!-- HTML5 Shim and Respond.js add IE8 support of HTML5 elements and media queries -->*/
/*     {% include 'BraincraftedBootstrapBundle::ie8-support.html.twig' %}*/
/* */
/* </head>*/
/* */
/* <body>*/
/* */
/*   {% block body %}*/
/*   {% endblock %}*/
/*     <!-- jQuery (necessary for Bootstraps JavaScript plugins) -->*/
/*     <script src="{{ asset('js/jquery.js') }}"></script>*/
/*     <!-- Include all JavaScripts, compiled by Assetic -->*/
/*     <script src="{{ asset('js/bootstrap.js') }}"></script>*/
/*     {% block javascripts %}*/
/* */
/* {% endblock %}*/
/* </body>*/
/* </html>*/
/* */
