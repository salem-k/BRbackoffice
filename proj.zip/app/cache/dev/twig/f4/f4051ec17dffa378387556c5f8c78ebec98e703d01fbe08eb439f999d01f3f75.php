<?php

/* AppBundle:Event:new.html.twig */
class __TwigTemplate_c83594d8cff91990897d8a051b9e102c5bba180aeb3b5629f05447b507459db9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("AppBundle::layout.html.twig", "AppBundle:Event:new.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "AppBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c4136b2172b748d5cebae23b87cf6cf634db4266f6253b362de976f164f5fae7 = $this->env->getExtension("native_profiler");
        $__internal_c4136b2172b748d5cebae23b87cf6cf634db4266f6253b362de976f164f5fae7->enter($__internal_c4136b2172b748d5cebae23b87cf6cf634db4266f6253b362de976f164f5fae7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Event:new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c4136b2172b748d5cebae23b87cf6cf634db4266f6253b362de976f164f5fae7->leave($__internal_c4136b2172b748d5cebae23b87cf6cf634db4266f6253b362de976f164f5fae7_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_d4ed32d362e634621f162ad044156aef7cb1e67de5600d0a9be7b6ee9ca24832 = $this->env->getExtension("native_profiler");
        $__internal_d4ed32d362e634621f162ad044156aef7cb1e67de5600d0a9be7b6ee9ca24832->enter($__internal_d4ed32d362e634621f162ad044156aef7cb1e67de5600d0a9be7b6ee9ca24832_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "<h1>Event creation</h1>

    ";
        // line 6
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form');
        echo "

        <ul class=\"record_actions\">
    <li>
        <a href=\"";
        // line 10
        echo $this->env->getExtension('routing')->getPath("event");
        echo "\">
            Back to the list
        </a>
    </li>
</ul>
";
        
        $__internal_d4ed32d362e634621f162ad044156aef7cb1e67de5600d0a9be7b6ee9ca24832->leave($__internal_d4ed32d362e634621f162ad044156aef7cb1e67de5600d0a9be7b6ee9ca24832_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Event:new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  51 => 10,  44 => 6,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'AppBundle::layout.html.twig' %}*/
/* */
/* {% block body -%}*/
/*     <h1>Event creation</h1>*/
/* */
/*     {{ form(form) }}*/
/* */
/*         <ul class="record_actions">*/
/*     <li>*/
/*         <a href="{{ path('event') }}">*/
/*             Back to the list*/
/*         </a>*/
/*     </li>*/
/* </ul>*/
/* {% endblock %}*/
/* */
