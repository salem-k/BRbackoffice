<?php

/* AppBundle:Sequence:new.html.twig */
class __TwigTemplate_16a97d00cb2e599958ad12821c66e15ff7cf0b156fe9dee96c1a7b57253b190e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("AppBundle::layout.html.twig", "AppBundle:Sequence:new.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "AppBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5dd5be71919179010f8289c37de14b1040efcfb39ea899d90cf3e261f4b57ae1 = $this->env->getExtension("native_profiler");
        $__internal_5dd5be71919179010f8289c37de14b1040efcfb39ea899d90cf3e261f4b57ae1->enter($__internal_5dd5be71919179010f8289c37de14b1040efcfb39ea899d90cf3e261f4b57ae1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Sequence:new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_5dd5be71919179010f8289c37de14b1040efcfb39ea899d90cf3e261f4b57ae1->leave($__internal_5dd5be71919179010f8289c37de14b1040efcfb39ea899d90cf3e261f4b57ae1_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_8f972185d7798b552452b5e86290c9f86ed336577a0df12df0a6f3d65a4ba7e7 = $this->env->getExtension("native_profiler");
        $__internal_8f972185d7798b552452b5e86290c9f86ed336577a0df12df0a6f3d65a4ba7e7->enter($__internal_8f972185d7798b552452b5e86290c9f86ed336577a0df12df0a6f3d65a4ba7e7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "<h1>Sequence creation</h1>

    ";
        // line 6
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form');
        echo "

        <ul class=\"record_actions\">
    <li>
        <a href=\"";
        // line 10
        echo $this->env->getExtension('routing')->getPath("sequence");
        echo "\">
            Back to the list
        </a>
    </li>
</ul>
";
        
        $__internal_8f972185d7798b552452b5e86290c9f86ed336577a0df12df0a6f3d65a4ba7e7->leave($__internal_8f972185d7798b552452b5e86290c9f86ed336577a0df12df0a6f3d65a4ba7e7_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Sequence:new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  51 => 10,  44 => 6,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'AppBundle::layout.html.twig' %}*/
/* */
/* {% block body -%}*/
/*     <h1>Sequence creation</h1>*/
/* */
/*     {{ form(form) }}*/
/* */
/*         <ul class="record_actions">*/
/*     <li>*/
/*         <a href="{{ path('sequence') }}">*/
/*             Back to the list*/
/*         </a>*/
/*     </li>*/
/* </ul>*/
/* {% endblock %}*/
/* */
