<?php

/* TwigBundle:Exception:exception.css.twig */
class __TwigTemplate_6830a08ed4ca0efbd726ec4dc1a5e83378be5007fb93acea02da10f6556ec99e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d755efc47e50c6dc6ef2a6885031eb2be3fc509aa44f4167542623c6d433e51a = $this->env->getExtension("native_profiler");
        $__internal_d755efc47e50c6dc6ef2a6885031eb2be3fc509aa44f4167542623c6d433e51a->enter($__internal_d755efc47e50c6dc6ef2a6885031eb2be3fc509aa44f4167542623c6d433e51a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        $this->loadTemplate("TwigBundle:Exception:exception.txt.twig", "TwigBundle:Exception:exception.css.twig", 2)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        // line 3
        echo "*/
";
        
        $__internal_d755efc47e50c6dc6ef2a6885031eb2be3fc509aa44f4167542623c6d433e51a->leave($__internal_d755efc47e50c6dc6ef2a6885031eb2be3fc509aa44f4167542623c6d433e51a_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  27 => 3,  25 => 2,  22 => 1,);
    }
}
/* /**/
/* {% include 'TwigBundle:Exception:exception.txt.twig' with { 'exception': exception } %}*/
/* *//* */
/* */
