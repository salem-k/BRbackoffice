<?php

/* AppBundle::layout.html.twig */
class __TwigTemplate_f42866430f28e8da7c565e3b06a31bb883ae8151ac0b6707a2542007dc219d90 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ef8840af479ee1b24da97057376eea2976c16261c63775d59df5d1f4265eb42a = $this->env->getExtension("native_profiler");
        $__internal_ef8840af479ee1b24da97057376eea2976c16261c63775d59df5d1f4265eb42a->enter($__internal_ef8840af479ee1b24da97057376eea2976c16261c63775d59df5d1f4265eb42a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle::layout.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
<head>

    <title>Bootstrap 101 Template</title>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
    <!-- Bootstrap -->
    <link href=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("css/bootstrap.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" media=\"screen\">

    <!-- HTML5 Shim and Respond.js add IE8 support of HTML5 elements and media queries -->
    ";
        // line 11
        $this->loadTemplate("BraincraftedBootstrapBundle::ie8-support.html.twig", "AppBundle::layout.html.twig", 11)->display($context);
        // line 12
        echo "
</head>

<body>

  ";
        // line 17
        $this->displayBlock('body', $context, $blocks);
        // line 19
        echo "
    <!-- jQuery (necessary for Bootstraps JavaScript plugins) -->
    <script src=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("js/jquery.js"), "html", null, true);
        echo "\"></script>
    <!-- Include all JavaScripts, compiled by Assetic -->
    <script src=\"";
        // line 23
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("js/bootstrap.js"), "html", null, true);
        echo "\"></script>
</body>
</html>
";
        
        $__internal_ef8840af479ee1b24da97057376eea2976c16261c63775d59df5d1f4265eb42a->leave($__internal_ef8840af479ee1b24da97057376eea2976c16261c63775d59df5d1f4265eb42a_prof);

    }

    // line 17
    public function block_body($context, array $blocks = array())
    {
        $__internal_8d726f5ea9db57b7c4c507516a80548dad41ad087562071cce6fb07b234a0c9c = $this->env->getExtension("native_profiler");
        $__internal_8d726f5ea9db57b7c4c507516a80548dad41ad087562071cce6fb07b234a0c9c->enter($__internal_8d726f5ea9db57b7c4c507516a80548dad41ad087562071cce6fb07b234a0c9c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 18
        echo "    ";
        
        $__internal_8d726f5ea9db57b7c4c507516a80548dad41ad087562071cce6fb07b234a0c9c->leave($__internal_8d726f5ea9db57b7c4c507516a80548dad41ad087562071cce6fb07b234a0c9c_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle::layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  75 => 18,  69 => 17,  58 => 23,  53 => 21,  49 => 19,  47 => 17,  40 => 12,  38 => 11,  32 => 8,  23 => 1,);
    }
}
/* <!DOCTYPE html>*/
/* <html>*/
/* <head>*/
/* */
/*     <title>Bootstrap 101 Template</title>*/
/*     <meta name="viewport" content="width=device-width, initial-scale=1.0">*/
/*     <!-- Bootstrap -->*/
/*     <link href="{{ asset('css/bootstrap.css') }}" rel="stylesheet" media="screen">*/
/* */
/*     <!-- HTML5 Shim and Respond.js add IE8 support of HTML5 elements and media queries -->*/
/*     {% include 'BraincraftedBootstrapBundle::ie8-support.html.twig' %}*/
/* */
/* </head>*/
/* */
/* <body>*/
/* */
/*   {% block body %}*/
/*     {% endblock %}*/
/* */
/*     <!-- jQuery (necessary for Bootstraps JavaScript plugins) -->*/
/*     <script src="{{ asset('js/jquery.js') }}"></script>*/
/*     <!-- Include all JavaScripts, compiled by Assetic -->*/
/*     <script src="{{ asset('js/bootstrap.js') }}"></script>*/
/* </body>*/
/* </html>*/
/* */
