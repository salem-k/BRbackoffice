<?php

/* TwigBundle:Exception:error.txt.twig */
class __TwigTemplate_8da4c5cd2ef70d8ac0424271b51e2dd38c1c43e3a2d716dfe40b5f55903cb8a9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f615da06806cc850532b8f0e0d9b3d3bc63a8369400d4e5be9ba48321a93be9c = $this->env->getExtension("native_profiler");
        $__internal_f615da06806cc850532b8f0e0d9b3d3bc63a8369400d4e5be9ba48321a93be9c->enter($__internal_f615da06806cc850532b8f0e0d9b3d3bc63a8369400d4e5be9ba48321a93be9c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.txt.twig"));

        // line 1
        echo "Oops! An Error Occurred
=======================

The server returned a \"";
        // line 4
        echo (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code"));
        echo " ";
        echo (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text"));
        echo "\".

Something is broken. Please let us know what you were doing when this error occurred.
We will fix it as soon as possible. Sorry for any inconvenience caused.
";
        
        $__internal_f615da06806cc850532b8f0e0d9b3d3bc63a8369400d4e5be9ba48321a93be9c->leave($__internal_f615da06806cc850532b8f0e0d9b3d3bc63a8369400d4e5be9ba48321a93be9c_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.txt.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  27 => 4,  22 => 1,);
    }
}
/* Oops! An Error Occurred*/
/* =======================*/
/* */
/* The server returned a "{{ status_code }} {{ status_text }}".*/
/* */
/* Something is broken. Please let us know what you were doing when this error occurred.*/
/* We will fix it as soon as possible. Sorry for any inconvenience caused.*/
/* */
