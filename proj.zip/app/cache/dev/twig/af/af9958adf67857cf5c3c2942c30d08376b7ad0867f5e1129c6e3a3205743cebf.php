<?php

/* WebProfilerBundle:Profiler:toolbar_redirect.html.twig */
class __TwigTemplate_e5cbfeaaf26f41f1d51615f5c69cf5e5078ec9cc8e6527e97e285c28b5f386eb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("TwigBundle::layout.html.twig", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "TwigBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_496b13a618cc761df1d6c7f959a7097ec0652c0d7e40208665dc9b28f2aa50c1 = $this->env->getExtension("native_profiler");
        $__internal_496b13a618cc761df1d6c7f959a7097ec0652c0d7e40208665dc9b28f2aa50c1->enter($__internal_496b13a618cc761df1d6c7f959a7097ec0652c0d7e40208665dc9b28f2aa50c1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_496b13a618cc761df1d6c7f959a7097ec0652c0d7e40208665dc9b28f2aa50c1->leave($__internal_496b13a618cc761df1d6c7f959a7097ec0652c0d7e40208665dc9b28f2aa50c1_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_1bfd250a8ee6bc54e89b55ceb384a4d6c80d1bfc6e774ec6bf5de5e3cd48bb68 = $this->env->getExtension("native_profiler");
        $__internal_1bfd250a8ee6bc54e89b55ceb384a4d6c80d1bfc6e774ec6bf5de5e3cd48bb68->enter($__internal_1bfd250a8ee6bc54e89b55ceb384a4d6c80d1bfc6e774ec6bf5de5e3cd48bb68_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Redirection Intercepted";
        
        $__internal_1bfd250a8ee6bc54e89b55ceb384a4d6c80d1bfc6e774ec6bf5de5e3cd48bb68->leave($__internal_1bfd250a8ee6bc54e89b55ceb384a4d6c80d1bfc6e774ec6bf5de5e3cd48bb68_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_ac9f6d07f66513f33b507cd8ff2abad503ad15e67292d5e9f3e46a8ba937a5f8 = $this->env->getExtension("native_profiler");
        $__internal_ac9f6d07f66513f33b507cd8ff2abad503ad15e67292d5e9f3e46a8ba937a5f8->enter($__internal_ac9f6d07f66513f33b507cd8ff2abad503ad15e67292d5e9f3e46a8ba937a5f8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"";
        // line 8
        echo twig_escape_filter($this->env, (isset($context["location"]) ? $context["location"] : $this->getContext($context, "location")), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, (isset($context["location"]) ? $context["location"] : $this->getContext($context, "location")), "html", null, true);
        echo "</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
";
        
        $__internal_ac9f6d07f66513f33b507cd8ff2abad503ad15e67292d5e9f3e46a8ba937a5f8->leave($__internal_ac9f6d07f66513f33b507cd8ff2abad503ad15e67292d5e9f3e46a8ba937a5f8_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:toolbar_redirect.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  57 => 8,  53 => 6,  47 => 5,  35 => 3,  11 => 1,);
    }
}
/* {% extends 'TwigBundle::layout.html.twig' %}*/
/* */
/* {% block title 'Redirection Intercepted' %}*/
/* */
/* {% block body %}*/
/*     <div class="sf-reset">*/
/*         <div class="block-exception">*/
/*             <h1>This request redirects to <a href="{{ location }}">{{ location }}</a>.</h1>*/
/* */
/*             <p>*/
/*                 <small>*/
/*                     The redirect was intercepted by the web debug toolbar to help debugging.*/
/*                     For more information, see the "intercept-redirects" option of the Profiler.*/
/*                 </small>*/
/*             </p>*/
/*         </div>*/
/*     </div>*/
/* {% endblock %}*/
/* */
