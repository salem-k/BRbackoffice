<?php

/* AppBundle:Sequence:edit.html.twig */
class __TwigTemplate_01a6f57ba3445f7bc71a71b007a426d5a710aaa7a156a33d2eb9f06c151a7977 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("AppBundle::layout.html.twig", "AppBundle:Sequence:edit.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "AppBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_322dd2b035c1ef0204e1171235c841ab66f42fa27d887eb6a173bb7b49494f21 = $this->env->getExtension("native_profiler");
        $__internal_322dd2b035c1ef0204e1171235c841ab66f42fa27d887eb6a173bb7b49494f21->enter($__internal_322dd2b035c1ef0204e1171235c841ab66f42fa27d887eb6a173bb7b49494f21_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Sequence:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_322dd2b035c1ef0204e1171235c841ab66f42fa27d887eb6a173bb7b49494f21->leave($__internal_322dd2b035c1ef0204e1171235c841ab66f42fa27d887eb6a173bb7b49494f21_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_a50dd3990a37c8a4aee4ddbf48eed84924db893de09b1886b74b1f12a32fdc95 = $this->env->getExtension("native_profiler");
        $__internal_a50dd3990a37c8a4aee4ddbf48eed84924db893de09b1886b74b1f12a32fdc95->enter($__internal_a50dd3990a37c8a4aee4ddbf48eed84924db893de09b1886b74b1f12a32fdc95_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "<h1>Sequence edit</h1>

    ";
        // line 6
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'form');
        echo "

        <ul class=\"record_actions\">
    <li>
        <a href=\"";
        // line 10
        echo $this->env->getExtension('routing')->getPath("sequence");
        echo "\">
            Back to the list
        </a>
    </li>
    <li>";
        // line 14
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form');
        echo "</li>
</ul>
";
        
        $__internal_a50dd3990a37c8a4aee4ddbf48eed84924db893de09b1886b74b1f12a32fdc95->leave($__internal_a50dd3990a37c8a4aee4ddbf48eed84924db893de09b1886b74b1f12a32fdc95_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Sequence:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  58 => 14,  51 => 10,  44 => 6,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'AppBundle::layout.html.twig' %}*/
/* */
/* {% block body -%}*/
/*     <h1>Sequence edit</h1>*/
/* */
/*     {{ form(edit_form) }}*/
/* */
/*         <ul class="record_actions">*/
/*     <li>*/
/*         <a href="{{ path('sequence') }}">*/
/*             Back to the list*/
/*         </a>*/
/*     </li>*/
/*     <li>{{ form(delete_form) }}</li>*/
/* </ul>*/
/* {% endblock %}*/
/* */
